﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STK
{
    public partial class BienDongSoDu : Form
    {
        public BienDongSoDu()
        {
            InitializeComponent();
        }
        private void button9_Click(object sender, EventArgs e)
        {
            GhiNhan gn = new GhiNhan();
            gn.ShowDialog();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            QuanlyKhachHang qlkh = new QuanlyKhachHang
            {
                TopLevel = false,
                FormBorderStyle = FormBorderStyle.None,
                Dock = DockStyle.Fill
            };

            panel1.Controls.Add(qlkh);
            qlkh.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string maGiaoDich = txtMaGiaoDich.Text.Trim(); 
            DateTime ngayGiaoDich = dtpNgayGiaoDich.Value; 

            string connectionString = "Server=LYCORIS;Database=DoAn1;User Id=admin;Password=1234;";
            string query;

            if (string.IsNullOrEmpty(maGiaoDich))
            {
                query = "SELECT * FROM BienDongSoDu WHERE CONVERT(DATE, NgayGiaoDich) = @NgayGiaoDich ORDER BY NgayGiaoDich DESC";
            }
            else
            {
                query = "SELECT * FROM BienDongSoDu WHERE MaSo = @MaGiaoDich AND CONVERT(DATE, NgayGiaoDich) = @NgayGiaoDich ORDER BY NgayGiaoDich DESC";
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@NgayGiaoDich", ngayGiaoDich.Date); 

                        if (!string.IsNullOrEmpty(maGiaoDich))
                        {
                            cmd.Parameters.AddWithValue("@MaGiaoDich", maGiaoDich); 
                        }

                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        dgvGiaoDich.DataSource = dt;
                        dgvGiaoDich.Columns["NgayGiaoDich"].SortMode = DataGridViewColumnSortMode.Automatic;

                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = "Server=LYCORIS;Database=DoAn1;User Id=admin;Password=1234;";
            string query = "SELECT MaSo, NgayGiaoDich, SoTien, SoDuCuoi, MoTa FROM BienDongSoDu";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("Không có dữ liệu giao dịch để hiển thị.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }

                    dgvGiaoDich.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}

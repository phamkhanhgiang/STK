﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Xceed.Document.NET;
using Xceed.Words.NET;

namespace STK
{
    public partial class BaoCaoSTK : Form
    {
        public BaoCaoSTK()
        {
            InitializeComponent();
        }

        private void BaoCaoSTK_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "Word Files|*.docx",
                Title = "Lưu Báo Cáo Mở/Đóng Sổ Tiết Kiệm"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = saveFileDialog.FileName;

                using (var doc = DocX.Create(filePath))
                {
                    doc.InsertParagraph("Báo Cáo Mở/Đóng Sổ Tiết Kiệm\n")
                        .FontSize(20)
                        .Bold()
                        .Alignment = Alignment.center;

                    doc.InsertParagraph($"Từ ngày: {dtpTuNgay.Value.ToShortDateString()} đến ngày: {dtpDenNgay.Value.ToShortDateString()}:\n ")
                        .FontSize(16);

                    doc.InsertParagraph($"Lượng sổ tiết kiệm đã mở: {lblSoMo.Text}")
                        .FontSize(14);
                    doc.InsertParagraph($"Lượng sổ tiết kiệm đã đóng: {lblSoDong.Text}")
                        .FontSize(14);
                    doc.InsertParagraph($"Chênh lệch số lượng sổ đã mở/đóng: {lblChenhLechMoDong.Text}")
                        .FontSize(14);

                    doc.Save();
                }

                MessageBox.Show("Báo cáo đã được lưu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DateTime tuNgay = dtpTuNgay.Value.Date; 
            DateTime denNgay = dtpDenNgay.Value.Date.AddDays(1).AddTicks(-1);

            string query = @"
SELECT 
    SUM(CASE WHEN SoMo IS NOT NULL THEN SoMo ELSE 0 END) AS TongSoMo,
    SUM(CASE WHEN SoDong IS NOT NULL THEN SoDong ELSE 0 END) AS TongSoDong,
    SUM(CASE WHEN SoMo IS NOT NULL THEN SoMo ELSE 0 END) - 
    SUM(CASE WHEN SoDong IS NOT NULL THEN SoDong ELSE 0 END) AS ChenhLechMoDong
FROM BaoCaoMoDongSo
WHERE NgayThongKe >= @TuNgay AND NgayThongKe < @DenNgay";

            using (SqlConnection connection = new SqlConnection(@"Server=LYCORIS;Database=DoAn1;User ID=admin;Password=1234;"))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@TuNgay", tuNgay);
                command.Parameters.AddWithValue("@DenNgay", denNgay);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    lblSoMo.Text = reader["TongSoMo"].ToString();
                    lblSoDong.Text = reader["TongSoDong"].ToString();
                    lblChenhLechMoDong.Text = reader["ChenhLechMoDong"].ToString();
                }

                reader.Close();
            }

        }

        private void lblChenhlechMo_Click(object sender, EventArgs e)
        {

        }
    }
}

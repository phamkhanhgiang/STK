﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STK
{
    public partial class ThemKhachHang : Form
    {
        public ThemKhachHang()
        {
            InitializeComponent();
        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
        private int LayMaKhachHangMoi()
        {
            string connectionString = "Server=LYCORIS;Database=DoAn1;User Id=admin;Password=1234;";
            string query = "SELECT ISNULL(MAX(MaKH), 0) + 1 FROM KhachHang"; 

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        return (int)cmd.ExecuteScalar(); 
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return 0;
                }
            }
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            string cccd = txtCCCD.Text.Trim();
            string tenKhachHang = txtTenKhachHang.Text.Trim();
            string soDienThoai = txtSoDienThoai.Text.Trim();
            string diaChi = txtDiaChi.Text.Trim();

            if (string.IsNullOrEmpty(cccd) || string.IsNullOrEmpty(tenKhachHang) || string.IsNullOrEmpty(soDienThoai))
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = "Server=LYCORIS;Database=DoAn1;User Id=admin;Password=1234;";
            string queryCheckCCCD = "SELECT COUNT(*) FROM KhachHang WHERE CCCD = @CCCD";
            string queryCheckSDT = "SELECT COUNT(*) FROM KhachHang WHERE SDT = @SoDienThoai";
            string queryInsert = "INSERT INTO KhachHang (HoTen, CCCD, SDT, DiaChi) VALUES (@TenKH, @CCCD, @SoDienThoai, @DiaChi)";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();

                    using (SqlCommand cmdCheckCCCD = new SqlCommand(queryCheckCCCD, conn))
                    {
                        cmdCheckCCCD.Parameters.AddWithValue("@CCCD", cccd);
                        int countCCCD = (int)cmdCheckCCCD.ExecuteScalar();
                        if (countCCCD > 0)
                        {
                            MessageBox.Show("CCCD đã tồn tại. Vui lòng kiểm tra lại thông tin!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    using (SqlCommand cmdCheckSDT = new SqlCommand(queryCheckSDT, conn))
                    {
                        cmdCheckSDT.Parameters.AddWithValue("@SoDienThoai", soDienThoai);
                        int countSDT = (int)cmdCheckSDT.ExecuteScalar();
                        if (countSDT > 0)
                        {
                            MessageBox.Show("Số điện thoại đã tồn tại. Vui lòng kiểm tra lại thông tin!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    using (SqlCommand cmdInsert = new SqlCommand(queryInsert, conn))
                    {
                        cmdInsert.Parameters.AddWithValue("@TenKH", tenKhachHang);
                        cmdInsert.Parameters.AddWithValue("@CCCD", cccd);
                        cmdInsert.Parameters.AddWithValue("@SoDienThoai", soDienThoai);
                        cmdInsert.Parameters.AddWithValue("@DiaChi", diaChi);

                        int rowsAffected = cmdInsert.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Thêm khách hàng thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            txtMaKhachHang.Text = LayMaKhachHangMoi().ToString(); 
                            txtCCCD.Clear();
                            txtTenKhachHang.Clear();
                            txtSoDienThoai.Clear();
                            txtDiaChi.Clear();
                        }
                        else
                        {
                            MessageBox.Show("Không thể thêm khách hàng. Vui lòng thử lại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ThemKhachHang_Load(object sender, EventArgs e)
        {
            int maKhachHangMoi = LayMaKhachHangMoi();
            if (maKhachHangMoi > 0)
            {
                txtMaKhachHang.Text = maKhachHangMoi.ToString();
            }
            else
            {
                MessageBox.Show("Không thể lấy mã khách hàng mới. Vui lòng kiểm tra kết nối cơ sở dữ liệu!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}

﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace STK
{
    public partial class DSSoTietKiem : Form
    {
        private QuanlyKhachHang previousForm;
        private void LoadLoaiSoToComboBox()
        {
            string query = "SELECT DISTINCT LoaiSo FROM SoTietKiem";

            using (SqlConnection conn = new SqlConnection(@"Server=LYCORIS;Database=DoAn1;User ID=admin;Password=1234;"))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        comboBoxLoaiSo.Items.Add(reader["LoaiSo"].ToString());
                    }

                    comboBoxLoaiSo.SelectedIndex = 0; 
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void DSSoTietKiem_Load(object sender, EventArgs e)
        {
            string query = "SELECT * FROM SoTietKiem";
            using (SqlConnection conn = new SqlConnection(@"Server=LYCORIS;Database=DoAn1;User ID=admin;Password=1234;"))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public DSSoTietKiem(QuanlyKhachHang form3)
        {
            InitializeComponent();
            previousForm = form3;
        }

        private void button1_Click(object sender, EventArgs e)
        {


        }
        private void button2_Click(object sender, EventArgs e)
        {
            SoTietKiem stk = new SoTietKiem();
            stk.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DongSo ds = new DongSo();
            ds.ShowDialog();
        }
        private void button10_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            QuanlyKhachHang qlkh = new QuanlyKhachHang
            {
                TopLevel = false,
                FormBorderStyle = FormBorderStyle.None,
                Dock = DockStyle.Fill
            };

            panel1.Controls.Add(qlkh);
            qlkh.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void comboBoxLoaiSo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedLoaiSo = comboBoxLoaiSo.SelectedItem.ToString();

            string query = selectedLoaiSo == "Tất cả"
                ? "SELECT * FROM SoTietKiem" 
                : "SELECT * FROM SoTietKiem WHERE LoaiSo = @LoaiSo"; 

            using (SqlConnection conn = new SqlConnection(@"Server=LYCORIS;Database=DoAn1;User ID=admin;Password=1234;"))
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);

                    if (selectedLoaiSo != "Tất cả")
                    {
                        cmd.Parameters.AddWithValue("@LoaiSo", selectedLoaiSo);
                    }

                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dataGridView1.DataSource = dataTable; 
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}

﻿namespace STK
{
    partial class QuanlyKhachHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            panel1 = new Panel();
            label1 = new Label();
            txtDiaChi = new TextBox();
            txtSoDienThoai = new TextBox();
            txtTenKhachHang = new TextBox();
            txtCCCD = new TextBox();
            txtMaKH = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            dgvThongTinKhachHang = new DataGridView();
            button7 = new Button();
            button11 = new Button();
            txtMaKhachHang = new TextBox();
            button10 = new Button();
            button9 = new Button();
            panel2 = new Panel();
            button8 = new Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvThongTinKhachHang).BeginInit();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(label1);
            panel1.Controls.Add(txtDiaChi);
            panel1.Controls.Add(txtSoDienThoai);
            panel1.Controls.Add(txtTenKhachHang);
            panel1.Controls.Add(txtCCCD);
            panel1.Controls.Add(txtMaKH);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(dgvThongTinKhachHang);
            panel1.Controls.Add(button7);
            panel1.Controls.Add(button11);
            panel1.Controls.Add(txtMaKhachHang);
            panel1.Controls.Add(button10);
            panel1.Controls.Add(button9);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(853, 584);
            panel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(399, 116);
            label1.Name = "label1";
            label1.Size = new Size(92, 15);
            label1.TabIndex = 38;
            label1.Text = "Mã khách hàng:";
            // 
            // txtDiaChi
            // 
            txtDiaChi.Location = new Point(165, 435);
            txtDiaChi.Multiline = true;
            txtDiaChi.Name = "txtDiaChi";
            txtDiaChi.Size = new Size(336, 55);
            txtDiaChi.TabIndex = 37;
            // 
            // txtSoDienThoai
            // 
            txtSoDienThoai.Location = new Point(410, 371);
            txtSoDienThoai.Name = "txtSoDienThoai";
            txtSoDienThoai.Size = new Size(143, 23);
            txtSoDienThoai.TabIndex = 36;
            // 
            // txtTenKhachHang
            // 
            txtTenKhachHang.Location = new Point(149, 404);
            txtTenKhachHang.Name = "txtTenKhachHang";
            txtTenKhachHang.Size = new Size(156, 23);
            txtTenKhachHang.TabIndex = 35;
            // 
            // txtCCCD
            // 
            txtCCCD.Location = new Point(611, 374);
            txtCCCD.Name = "txtCCCD";
            txtCCCD.Size = new Size(158, 23);
            txtCCCD.TabIndex = 34;
            // 
            // txtMaKH
            // 
            txtMaKH.Location = new Point(149, 367);
            txtMaKH.Name = "txtMaKH";
            txtMaKH.ReadOnly = true;
            txtMaKH.Size = new Size(102, 23);
            txtMaKH.TabIndex = 33;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label6.Location = new Point(100, 438);
            label6.Name = "label6";
            label6.Size = new Size(44, 15);
            label6.TabIndex = 32;
            label6.Text = "Địa chỉ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label5.Location = new Point(324, 374);
            label5.Name = "label5";
            label5.Size = new Size(80, 15);
            label5.TabIndex = 31;
            label5.Text = "Số điện thoại";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label4.Location = new Point(559, 377);
            label4.Name = "label4";
            label4.Size = new Size(37, 15);
            label4.TabIndex = 30;
            label4.Text = "CCCD";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label3.Location = new Point(53, 407);
            label3.Name = "label3";
            label3.Size = new Size(93, 15);
            label3.TabIndex = 29;
            label3.Text = "Tên khách hàng";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label2.Location = new Point(53, 371);
            label2.Name = "label2";
            label2.Size = new Size(90, 15);
            label2.TabIndex = 28;
            label2.Text = "Mã khách hàng";
            // 
            // dgvThongTinKhachHang
            // 
            dgvThongTinKhachHang.AllowUserToAddRows = false;
            dgvThongTinKhachHang.AllowUserToDeleteRows = false;
            dgvThongTinKhachHang.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvThongTinKhachHang.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvThongTinKhachHang.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvThongTinKhachHang.Location = new Point(53, 143);
            dgvThongTinKhachHang.Name = "dgvThongTinKhachHang";
            dgvThongTinKhachHang.ReadOnly = true;
            dgvThongTinKhachHang.RowHeadersVisible = false;
            dgvThongTinKhachHang.Size = new Size(715, 218);
            dgvThongTinKhachHang.TabIndex = 27;
            // 
            // button7
            // 
            button7.BackColor = Color.DarkGreen;
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button7.ForeColor = Color.White;
            button7.Location = new Point(693, 112);
            button7.Name = "button7";
            button7.Size = new Size(75, 23);
            button7.TabIndex = 22;
            button7.Text = "Tìm kiếm";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click_1;
            // 
            // button11
            // 
            button11.BackColor = Color.DarkGreen;
            button11.FlatAppearance.BorderSize = 0;
            button11.FlatStyle = FlatStyle.Flat;
            button11.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button11.ForeColor = Color.White;
            button11.Location = new Point(578, 516);
            button11.Name = "button11";
            button11.Size = new Size(191, 56);
            button11.TabIndex = 26;
            button11.Text = "Biến động số dư";
            button11.UseVisualStyleBackColor = false;
            button11.Click += button11_Click;
            // 
            // txtMaKhachHang
            // 
            txtMaKhachHang.Location = new Point(497, 112);
            txtMaKhachHang.Name = "txtMaKhachHang";
            txtMaKhachHang.Size = new Size(187, 23);
            txtMaKhachHang.TabIndex = 21;
            // 
            // button10
            // 
            button10.BackColor = Color.DarkGreen;
            button10.FlatAppearance.BorderSize = 0;
            button10.FlatStyle = FlatStyle.Flat;
            button10.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button10.ForeColor = Color.White;
            button10.Location = new Point(344, 516);
            button10.Name = "button10";
            button10.Size = new Size(191, 56);
            button10.TabIndex = 25;
            button10.Text = "Quản lý sổ tiết kiệm";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click;
            // 
            // button9
            // 
            button9.BackColor = Color.DarkGreen;
            button9.FlatAppearance.BorderSize = 0;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button9.ForeColor = Color.White;
            button9.Location = new Point(100, 516);
            button9.Name = "button9";
            button9.Size = new Size(191, 56);
            button9.TabIndex = 24;
            button9.Text = "Cập nhật thông tin";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(25, 51, 17);
            panel2.Controls.Add(button8);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(853, 100);
            panel2.TabIndex = 23;
            // 
            // button8
            // 
            button8.BackColor = Color.FromArgb(25, 51, 17);
            button8.Dock = DockStyle.Right;
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            button8.ForeColor = Color.White;
            button8.Location = new Point(603, 0);
            button8.Name = "button8";
            button8.Size = new Size(250, 100);
            button8.TabIndex = 2;
            button8.Text = "Thêm khách hàng";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // QuanlyKhachHang
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.FromArgb(233, 250, 227);
            ClientSize = new Size(853, 584);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "QuanlyKhachHang";
            Text = "Form3";
            Load += Form3_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvThongTinKhachHang).EndInit();
            panel2.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private TextBox txtDiaChi;
        private TextBox txtSoDienThoai;
        private TextBox txtTenKhachHang;
        private TextBox txtCCCD;
        private TextBox txtMaKH;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private DataGridView dgvThongTinKhachHang;
        private Button button7;
        private Button button11;
        private TextBox txtMaKhachHang;
        private Button button10;
        private Button button9;
        private Panel panel2;
        private Button button8;
        private Label label1;
    }
}
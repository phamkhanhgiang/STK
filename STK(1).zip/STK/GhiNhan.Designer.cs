﻿namespace STK
{
    partial class GhiNhan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dateTimePicker1 = new DateTimePicker();
            txtSoTien = new TextBox();
            txtMaSo = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            panel1 = new Panel();
            button10 = new Button();
            cbLoaiGiaoDich = new ComboBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Enabled = false;
            dateTimePicker1.Location = new Point(166, 189);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(182, 23);
            dateTimePicker1.TabIndex = 34;
            // 
            // txtSoTien
            // 
            txtSoTien.Location = new Point(166, 231);
            txtSoTien.Name = "txtSoTien";
            txtSoTien.Size = new Size(182, 23);
            txtSoTien.TabIndex = 31;
            // 
            // txtMaSo
            // 
            txtMaSo.Location = new Point(166, 148);
            txtMaSo.Name = "txtMaSo";
            txtMaSo.Size = new Size(182, 23);
            txtMaSo.TabIndex = 30;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label5.Location = new Point(34, 273);
            label5.Name = "label5";
            label5.Size = new Size(109, 15);
            label5.TabIndex = 29;
            label5.Text = "Chọn loại giao dịch";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label4.Location = new Point(35, 189);
            label4.Name = "label4";
            label4.Size = new Size(87, 15);
            label4.TabIndex = 28;
            label4.Text = "Ngày giao dịch";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label3.Location = new Point(34, 231);
            label3.Name = "label3";
            label3.Size = new Size(98, 15);
            label3.TabIndex = 27;
            label3.Text = "Số tiền giao dịch";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label2.Location = new Point(35, 151);
            label2.Name = "label2";
            label2.Size = new Size(93, 15);
            label2.TabIndex = 26;
            label2.Text = "Mã sổ tiết kiệm";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 30F, FontStyle.Bold);
            label1.Location = new Point(12, 69);
            label1.Name = "label1";
            label1.Size = new Size(374, 54);
            label1.TabIndex = 25;
            label1.Text = "Ghi nhận giao dịch";
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(25, 51, 17);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(391, 69);
            panel1.TabIndex = 35;
            // 
            // button10
            // 
            button10.BackColor = Color.DarkGreen;
            button10.FlatAppearance.BorderSize = 0;
            button10.FlatStyle = FlatStyle.Flat;
            button10.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button10.ForeColor = Color.White;
            button10.Location = new Point(218, 317);
            button10.Name = "button10";
            button10.Size = new Size(130, 32);
            button10.TabIndex = 36;
            button10.Text = "Ghi nhận";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click;
            // 
            // cbLoaiGiaoDich
            // 
            cbLoaiGiaoDich.FormattingEnabled = true;
            cbLoaiGiaoDich.Items.AddRange(new object[] { "Nạp tiền", "Rút tiền" });
            cbLoaiGiaoDich.Location = new Point(166, 273);
            cbLoaiGiaoDich.Name = "cbLoaiGiaoDich";
            cbLoaiGiaoDich.Size = new Size(182, 23);
            cbLoaiGiaoDich.TabIndex = 37;
            cbLoaiGiaoDich.SelectedIndexChanged += cbLoaiSo_SelectedIndexChanged;
            // 
            // button1
            // 
            button1.BackColor = Color.DarkGreen;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(35, 317);
            button1.Name = "button1";
            button1.Size = new Size(130, 32);
            button1.TabIndex = 38;
            button1.Text = "Đóng";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // GhiNhan
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(391, 375);
            Controls.Add(button1);
            Controls.Add(cbLoaiGiaoDich);
            Controls.Add(button10);
            Controls.Add(panel1);
            Controls.Add(dateTimePicker1);
            Controls.Add(txtSoTien);
            Controls.Add(txtMaSo);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "GhiNhan";
            Text = "Ghi nhận giao dịch";
            Load += GhiNhan_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DateTimePicker dateTimePicker1;
        private TextBox txtSoTien;
        private TextBox txtMaSo;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Panel panel1;
        private Button button10;
        private ComboBox cbLoaiGiaoDich;
        private Button button1;
    }
}
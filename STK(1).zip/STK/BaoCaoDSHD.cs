﻿using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Xceed.Words.NET;

namespace STK
{
    public partial class BaoCaoDSHD : Form
    {
        public BaoCaoDSHD()
        {
            InitializeComponent();
        }

        private void BaoCaoDSHD_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(@"Server=LYCORIS;Database=DoAn1;User ID=admin;Password=1234;"))
                {
                    conn.Open();

                    // Truy vấn dữ liệu từ bảng BaoCaoDoanhSoHoatDong
                    string query = @"
            SELECT 
                ISNULL(SUM(TongThu), 0) AS TongThu,
                ISNULL(SUM(TongChi), 0) AS TongChi,
                ISNULL(SUM(TongThu) - SUM(TongChi), 0) AS ChenhLech
            FROM BaoCaoDoanhSoHoatDong
            WHERE NgayThongKe BETWEEN @FromDate AND @ToDate;";

                    SqlCommand cmd = new SqlCommand(query, conn);

                    // Truyền tham số từ giao diện (Từ ngày - Đến ngày)
                    cmd.Parameters.AddWithValue("@FromDate", dtpFromDate.Value.Date);
                    cmd.Parameters.AddWithValue("@ToDate", dtpToDate.Value.Date);

                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        // Lấy dữ liệu từ kết quả truy vấn
                        decimal tongThu = reader.GetDecimal(0);
                        decimal tongChi = reader.GetDecimal(1);
                        decimal chenhLechThuChi = reader.GetDecimal(2);

                        // Định dạng dữ liệu và gán vào giao diện
                        lblTongThu.Text = $"{tongThu:0,0 VNĐ}";
                        lblTongChi.Text = $"{tongChi:0,0 VNĐ}";
                        lblChenhLechThu.Text = $"{chenhLechThuChi:0,0 VNĐ}";
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                // Xử lý lỗi và hiển thị thông báo
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void SaveReport()
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog
                {
                    Filter = "Word Files|*.docx",
                    Title = "Lưu báo cáo doanh số hoạt động"
                };

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName;

                    using (var doc = DocX.Create(filePath))
                    {
                        var title = doc.InsertParagraph("Báo cáo doanh số hoạt động")
                                        .FontSize(16)
                                        .Bold();
                        title.Alignment = Xceed.Document.NET.Alignment.center;

                        doc.InsertParagraph("\n");

                        string tongTienNap = lblTongThu.Text;
                        string tongTienRut = lblTongChi.Text;
                        string chenhlechThu = lblChenhLechThu.Text;

                        doc.InsertParagraph($"Tổng số tiền nạp vào: {tongTienNap}").FontSize(12);
                        doc.InsertParagraph($"Tổng số tiền rút ra: {tongTienRut}").FontSize(12);
                        var chenhlech = 
                        doc.InsertParagraph($"Chênh lệch tổng thu/chi: {chenhlechThu}").FontSize(12);
                        doc.Save();
                    }

                    MessageBox.Show("Báo cáo đã được lưu thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void lblChenhLechThu_Click(object sender, EventArgs e)
        {

        }
    }
}

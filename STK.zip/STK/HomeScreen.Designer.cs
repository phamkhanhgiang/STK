﻿namespace STK
{
    partial class HomeScreen
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            panel1 = new Panel();
            button9 = new Button();
            button8 = new Button();
            button7 = new Button();
            panel3 = new Panel();
            panel2 = new Panel();
            button5 = new Button();
            pictureBox2 = new PictureBox();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            pictureBox1 = new PictureBox();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            button6 = new Button();
            label6 = new Label();
            panel_main = new Panel();
            button4 = new Button();
            label11 = new Label();
            panel5 = new Panel();
            lblSoSoTietKiem = new Label();
            lblSoKhachHang = new Label();
            label8 = new Label();
            label7 = new Label();
            panel4 = new Panel();
            label2 = new Label();
            label1 = new Label();
            pictureBox3 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel_main.SuspendLayout();
            panel5.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.DarkGreen;
            panel1.Controls.Add(button9);
            panel1.Controls.Add(button8);
            panel1.Controls.Add(button7);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1054, 641);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // button9
            // 
            button9.BackColor = SystemColors.Info;
            button9.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 163);
            button9.ForeColor = Color.Blue;
            button9.Location = new Point(56, 197);
            button9.Name = "button9";
            button9.Size = new Size(119, 46);
            button9.TabIndex = 5;
            button9.Text = "Trang chủ";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // button8
            // 
            button8.BackColor = Color.DarkGreen;
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button8.ForeColor = Color.White;
            button8.Location = new Point(411, 288);
            button8.Name = "button8";
            button8.Size = new Size(232, 65);
            button8.TabIndex = 6;
            button8.Text = "Báo cáo Sổ tiết kiệm";
            button8.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            button7.BackColor = Color.DarkGreen;
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button7.ForeColor = Color.White;
            button7.Location = new Point(411, 292);
            button7.Name = "button7";
            button7.Size = new Size(232, 56);
            button7.TabIndex = 5;
            button7.Text = "Quản lý khách hàng";
            button7.UseVisualStyleBackColor = false;
            // 
            // panel3
            // 
            panel3.BackColor = Color.DarkGreen;
            panel3.Location = new Point(230, 69);
            panel3.Name = "panel3";
            panel3.Size = new Size(826, 87);
            panel3.TabIndex = 1;
            // 
            // panel2
            // 
            panel2.Location = new Point(230, 49);
            panel2.Name = "panel2";
            panel2.Size = new Size(826, 194);
            panel2.TabIndex = 1;
            // 
            // button5
            // 
            button5.BackColor = Color.DarkGreen;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button5.ForeColor = Color.White;
            button5.Location = new Point(3, 565);
            button5.Name = "button5";
            button5.Size = new Size(229, 68);
            button5.TabIndex = 4;
            button5.Text = "Tài khoản";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Resource1.bank;
            pictureBox2.Location = new Point(56, 49);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(114, 107);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            // 
            // button3
            // 
            button3.BackColor = Color.DarkGreen;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button3.ForeColor = Color.White;
            button3.Location = new Point(0, 380);
            button3.Name = "button3";
            button3.Size = new Size(232, 65);
            button3.TabIndex = 2;
            button3.Text = "Báo cáo Sổ tiết kiệm";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button2_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.DarkGreen;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button2.ForeColor = Color.White;
            button2.Location = new Point(0, 314);
            button2.Name = "button2";
            button2.Size = new Size(232, 54);
            button2.TabIndex = 1;
            button2.Text = "Báo cáo doanh số hoạt động";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button3_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.DarkGreen;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(0, 249);
            button1.Name = "button1";
            button1.Size = new Size(232, 56);
            button1.TabIndex = 0;
            button1.Text = "Quản lý khách hàng";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Location = new Point(250, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(942, 637);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(0, 0);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(0, 0);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 0;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(0, 0);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 0;
            // 
            // label3
            // 
            label3.Location = new Point(0, 0);
            label3.Name = "label3";
            label3.Size = new Size(100, 23);
            label3.TabIndex = 0;
            // 
            // label4
            // 
            label4.Location = new Point(0, 0);
            label4.Name = "label4";
            label4.Size = new Size(100, 23);
            label4.TabIndex = 0;
            // 
            // label5
            // 
            label5.Location = new Point(0, 0);
            label5.Name = "label5";
            label5.Size = new Size(100, 23);
            label5.TabIndex = 0;
            // 
            // button6
            // 
            button6.Location = new Point(0, 0);
            button6.Name = "button6";
            button6.Size = new Size(75, 23);
            button6.TabIndex = 0;
            // 
            // label6
            // 
            label6.Location = new Point(0, 0);
            label6.Name = "label6";
            label6.Size = new Size(100, 23);
            label6.TabIndex = 0;
            // 
            // panel_main
            // 
            panel_main.Controls.Add(button4);
            panel_main.Controls.Add(label11);
            panel_main.Controls.Add(panel5);
            panel_main.Controls.Add(panel4);
            panel_main.Controls.Add(pictureBox3);
            panel_main.Location = new Point(230, 0);
            panel_main.Name = "panel_main";
            panel_main.Size = new Size(826, 641);
            panel_main.TabIndex = 3;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.Info;
            button4.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 163);
            button4.ForeColor = Color.Blue;
            button4.Location = new Point(693, 12);
            button4.Name = "button4";
            button4.Size = new Size(119, 46);
            button4.TabIndex = 4;
            button4.Text = "Thoát";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click_1;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label11.ForeColor = Color.FromArgb(25, 51, 17);
            label11.Location = new Point(35, 25);
            label11.Name = "label11";
            label11.Size = new Size(215, 25);
            label11.TabIndex = 3;
            label11.Text = "Ngân hàng nhóm 5, UIT";
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(25, 51, 17);
            panel5.Controls.Add(lblSoSoTietKiem);
            panel5.Controls.Add(lblSoKhachHang);
            panel5.Controls.Add(label8);
            panel5.Controls.Add(label7);
            panel5.Location = new Point(0, 510);
            panel5.Name = "panel5";
            panel5.Size = new Size(826, 144);
            panel5.TabIndex = 2;
            // 
            // lblSoSoTietKiem
            // 
            lblSoSoTietKiem.AutoSize = true;
            lblSoSoTietKiem.Font = new Font("Segoe UI", 12F);
            lblSoSoTietKiem.ForeColor = Color.White;
            lblSoSoTietKiem.Location = new Point(217, 66);
            lblSoSoTietKiem.Name = "lblSoSoTietKiem";
            lblSoSoTietKiem.Size = new Size(19, 21);
            lblSoSoTietKiem.TabIndex = 4;
            lblSoSoTietKiem.Text = "...";
            // 
            // lblSoKhachHang
            // 
            lblSoKhachHang.AutoSize = true;
            lblSoKhachHang.Font = new Font("Segoe UI", 12F);
            lblSoKhachHang.ForeColor = Color.White;
            lblSoKhachHang.Location = new Point(193, 34);
            lblSoKhachHang.Name = "lblSoKhachHang";
            lblSoKhachHang.Size = new Size(19, 21);
            lblSoKhachHang.TabIndex = 3;
            lblSoKhachHang.Text = "...";
            lblSoKhachHang.Click += label9_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F);
            label8.ForeColor = Color.White;
            label8.Location = new Point(80, 66);
            label8.Name = "label8";
            label8.Size = new Size(141, 21);
            label8.TabIndex = 2;
            label8.Text = "Tổng số sổ đã mở: ";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(80, 34);
            label7.Name = "label7";
            label7.Size = new Size(119, 21);
            label7.TabIndex = 1;
            label7.Text = "Số khách hàng: ";
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(25, 51, 17);
            panel4.Controls.Add(label2);
            panel4.Controls.Add(label1);
            panel4.Location = new Point(0, 72);
            panel4.Name = "panel4";
            panel4.Size = new Size(826, 93);
            panel4.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label2.ForeColor = SystemColors.Highlight;
            label2.Location = new Point(57, 43);
            label2.Name = "label2";
            label2.Size = new Size(79, 30);
            label2.TabIndex = 1;
            label2.Text = "Admin";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(57, 22);
            label1.Name = "label1";
            label1.Size = new Size(72, 21);
            label1.TabIndex = 0;
            label1.Text = "Xin chào,";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Resource1.panorama_3327550_1920;
            pictureBox3.Location = new Point(0, 171);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(832, 333);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // HomeScreen
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1054, 641);
            Controls.Add(panel_main);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "HomeScreen";
            Text = "Quản lý sổ tiết kiệm";
            Load += Form1_Load_1;
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel_main.ResumeLayout(false);
            panel_main.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
        }

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label6;

        #endregion

        private Panel panel_main;
        private Button button5;
        private Button button3;
        private Panel panel3;
        private Panel panel2;
        private Panel panel4;
        private PictureBox pictureBox3;
        private Panel panel5;
        private Label label1;
        private Label lblSoSoTietKiem;
        private Label lblSoKhachHang;
        private Label label8;
        private Label label7;
        private Label label11;
        private Button button4;
        private Label label2;
        private Button button7;
        private Button button8;
        private Button button9;
    }
}

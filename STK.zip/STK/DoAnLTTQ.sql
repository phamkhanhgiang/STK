﻿-- Xóa cơ sở dữ liệu nếu đã tồn tại
DROP DATABASE IF EXISTS DoAn1;

-- Tạo cơ sở dữ liệu mới
CREATE DATABASE DoAn1;
USE DoAn1;

-- Tạo bảng TaiKhoan
CREATE TABLE TaiKhoan (
    Username NVARCHAR(50) PRIMARY KEY,
    Password NVARCHAR(50) NOT NULL,
    Email NVARCHAR(100) NOT NULL
);

-- Tạo bảng KhachHang
CREATE TABLE KhachHang (
    MaKH INT PRIMARY KEY IDENTITY(1,1),
    HoTen NVARCHAR(100) NOT NULL,
    CCCD NVARCHAR(20) UNIQUE,
    SDT NVARCHAR(15) UNIQUE,
    DiaChi NVARCHAR(255) NOT NULL
);

-- Tạo bảng SoTietKiem
	CREATE TABLE SoTietKiem (
    MaSo INT PRIMARY KEY IDENTITY(1,1),
    MaKH INT NOT NULL, -- Mã khách hàng
    NgayMo DATE NOT NULL,
    SoDu DECIMAL(18, 2) NOT NULL,
    LoaiSo NVARCHAR(50) NOT NULL,
    FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH) -- Khóa ngoại
);


-- Tạo bảng BienDongSoDu
CREATE TABLE BienDongSoDu (
    MaSo INT,
    NgayGiaoDich DATE NOT NULL,
    SoTien DECIMAL(18, 2) NOT NULL,
    SoDuCuoi DECIMAL(18, 2) NOT NULL,
    MoTa NVARCHAR(255) NOT NULL,
    FOREIGN KEY (MaSo) REFERENCES SoTietKiem(MaSo)
);

-- Tạo bảng BaoCaoDoanhSoHoatDong
CREATE TABLE BaoCaoDoanhSoHoatDong (
    NgayThongKe DATE NOT NULL,
    MaSo INT NOT NULL,
    TongThu DECIMAL(18, 2) NOT NULL,
    TongChi DECIMAL(18, 2) NOT NULL,
    FOREIGN KEY (MaSo) REFERENCES SoTietKiem(MaSo)
);

-- Tạo bảng BaoCaoMoDongSo
CREATE TABLE BaoCaoMoDongSo (
    NgayThongKe DATE,
    MaSo INT NOT NULL,
    SoMo INT,
    SoDong INT,
    FOREIGN KEY (MaSo) REFERENCES SoTietKiem(MaSo)
);

-- Dữ liệu mẫu cho bảng TaiKhoan
INSERT INTO TaiKhoan(Username, Password, Email) VALUES
('admin', 'password123', 'admin1@example.com'),
('admin2', 'password456', 'admin2@example.com'),
('admin3', 'password789', 'admin3@example.com');

-- Dữ liệu mẫu cho bảng KhachHang
INSERT INTO KhachHang (HoTen, CCCD, SDT, DiaChi) VALUES
('Nguyen Van A', '123456789', '0123456789', '123 Nguyen Trai, Ha Noi'),
('Tran Thi B', '987654321', '0987654321', '456 Tran Hung Dao, Da Nang'),
('Le Van C', '456123789', '0912345678', '789 Le Lai, Ho Chi Minh City'),
('Nguyen Thi D', '321654987', '0923456789', '321 Nguyen Van Cu, Hai Phong'),
('Pham Minh E', '654321789', '0934567890', '654 Pham Van Dong, Can Tho');

-- Dữ liệu mẫu cho bảng SoTietKiem
INSERT INTO SoTietKiem (MaKH, NgayMo, SoDu, LoaiSo) VALUES 
    (1, '2024-01-01', 5000000, '1 tháng'),  -- Sổ 1 tháng
    (1, '2024-02-01', 10000000, '3 tháng'), -- Sổ 3 tháng
    (2, '2024-03-01', 15000000, '6 tháng'), -- Sổ 6 tháng
    (2, '2024-04-01', 20000000, '12 tháng'),-- Sổ 12 tháng
    (3, '2024-05-01', 25000000, '1 tháng'); -- Sổ 1 tháng

(2, '2024-02-01', 7000000, '6 tháng');

-- Dữ liệu mẫu cho bảng BienDongSoDu
INSERT INTO BienDongSoDu (MaSo, NgayGiaoDich, SoTien, SoDuCuoi, MoTa) VALUES
(1, '2024-01-02', 1000000, 6000000, 'Nạp tiền'),
(1, '2024-01-05', 2000000, 8000000, 'Nạp tiền'),
(2, '2024-02-11', 1500000, 11500000, 'Nạp tiền'),
(2, '2024-02-20', -500000, 11000000, 'Rút tiền'),
(3, '2024-03-02', 5000000, 20000000, 'Nạp tiền');

-- Dữ liệu mẫu cho bảng BaoCaoDoanhSoHoatDong
INSERT INTO BaoCaoDoanhSoHoatDong (NgayThongKe, MaSo, TongThu, TongChi) VALUES
('2024-01-15', 1, 15000000, 5000000),
('2024-01-15', 2, 20000000, 6000000),
('2024-01-15', 3, 25000000, 10000000),
('2024-01-16', 1, 10000000, 2000000),
('2024-01-17', 4, 1000000, 300000);

-- Dữ liệu mẫu cho bảng BaoCaoMoDongSo
INSERT INTO BaoCaoMoDongSo (NgayThongKe, MaSo, SoMo, SoDong) VALUES
('2024-01-15', 1, 5, 2),
('2024-01-15', 2, 8, 3),
('2024-01-16', 3, 6, 1),
('2024-01-17', 1, 7, 4),
('2024-01-18', 4, 4, 2);

-- Xuất dữ liệu từ các bảng
SELECT * FROM TaiKhoan;
SELECT * FROM KhachHang;
SELECT * FROM SoTietKiem;
SELECT * FROM BienDongSoDu;
SELECT * FROM BaoCaoDoanhSoHoatDong;
SELECT * FROM BaoCaoMoDongSo;

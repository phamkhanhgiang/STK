﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STK
{
    public partial class DongSo : Form
    {
        public DongSo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtMaKH_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaSo.Text)) return;

            int maSo;
            if (!int.TryParse(txtMaSo.Text, out maSo))
            {
                MessageBox.Show("Mã sổ phải là số nguyên!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtMaSo.Clear();
                return;
            }

            using (SqlConnection connection = new SqlConnection(@"Server=LYCORIS;Database=DoAn1;User ID=admin;Password=1234;"))
            {
                try
                {
                    connection.Open();

                    string query = @"SELECT kh.HoTen, stk.SoDu, GETDATE() AS NgayDong
                             FROM SoTietKiem stk
                             JOIN KhachHang kh ON stk.MaKH = kh.MaKH
                             WHERE stk.MaSo = @MaSo";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@MaSo", maSo);

                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtHoTen.Text = reader["HoTen"].ToString();
                                txtSoTien.Text = ((decimal)reader["SoDu"]).ToString("N2");
                                dtpNgayDong.Value = (DateTime)reader["NgayDong"];
                            }
                            else
                            {
                                MessageBox.Show("Mã sổ không tồn tại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                txtMaSo.Clear();
                                return;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Đã xảy ra lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaSo.Text)) return;

            int maSo = int.Parse(txtMaSo.Text);
            string connectionString = "your_connection_string_here";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string updateQuery = @"UPDATE SoTietKiem
                                   SET SoDu = 0, NgayDong = @NgayDong
                                   WHERE MaSo = @MaSo";

                    using (SqlCommand cmd = new SqlCommand(updateQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@NgayDong", DateTime.Now);
                        cmd.Parameters.AddWithValue("@MaSo", maSo);

                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Sổ tiết kiệm đã được đóng. Toàn bộ tiền đã được rút!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            txtMaSo.Clear();
                            txtHoTen.Clear();
                            txtSoTien.Clear();
                        }
                        else
                        {
                            MessageBox.Show("Đã xảy ra lỗi khi đóng sổ!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Đã xảy ra lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}

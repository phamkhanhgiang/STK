﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace STK
{
    public partial class QuanlyKhachHang : Form
    {
        public QuanlyKhachHang()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
        private void button11_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            BienDongSoDu bdsd = new BienDongSoDu()
            {
                TopLevel = false,
                FormBorderStyle = FormBorderStyle.None,
                Dock = DockStyle.Fill
            };
            panel1.Controls.Add(bdsd);
            bdsd.Show();
        }
        private void button8_Click(object sender, EventArgs e)
        {
            ThemKhachHang form2 = new ThemKhachHang();
            form2.ShowDialog();
        }
        private void button10_Click(object sender, EventArgs e)
        {
            panel1.Controls.Clear();
            DSSoTietKiem dss = new DSSoTietKiem(this)
            {
                TopLevel = false,
                FormBorderStyle = FormBorderStyle.None,
                Dock = DockStyle.Fill
            };
            panel1.Controls.Add(dss);
            dss.Show();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            // Lấy mã khách hàng từ TextBox
            string maKhachHang = txtMaKhachHang.Text.Trim();

            if (string.IsNullOrEmpty(maKhachHang))
            {
                MessageBox.Show("Vui lòng nhập mã khách hàng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = @"
        SELECT 
            MaKH AS [Mã Khách Hàng], 
            HoTen AS [Họ Tên], 
            CCCD, 
            SDT AS [Số Điện Thoại], 
            DiaChi AS [Địa Chỉ]
        FROM KhachHang
        WHERE MaKH = @MaKH";

            using (SqlConnection connection = new SqlConnection(@"Server=LYCORIS;Database=DoAn1;User ID=admin;Password=1234;"))
            {
                try
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@MaKH", maKhachHang);

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();

                    adapter.Fill(dataTable);

                    if (dataTable.Rows.Count == 0)
                    {
                        MessageBox.Show("Không tìm thấy khách hàng với mã này!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        dgvThongTinKhachHang.DataSource = dataTable;
                        txtMaKH.Text = txtMaKhachHang.Text;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Có lỗi xảy ra: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            string maKhachHang = txtMaKH.Text; 
            string hoTen = txtTenKhachHang.Text;      
            string soDienThoai = txtSoDienThoai.Text;
            string cccd = txtCCCD.Text;              
            string diaChi = txtDiaChi.Text;         

            if (string.IsNullOrWhiteSpace(maKhachHang))
            {
                MessageBox.Show("Vui lòng nhập mã khách hàng trước khi cập nhật!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query = "UPDATE KhachHang SET ";
            List<string> updates = new List<string>();
            Dictionary<string, object> parameters = new Dictionary<string, object>();

            if (!string.IsNullOrWhiteSpace(hoTen))
            {
                updates.Add("HoTen = @HoTen");
                parameters.Add("@HoTen", hoTen);
            }
            if (!string.IsNullOrWhiteSpace(soDienThoai))
            {
                updates.Add("SDT = @SoDienThoai");
                parameters.Add("@SoDienThoai", soDienThoai);
            }
            if (!string.IsNullOrWhiteSpace(cccd))
            {
                updates.Add("CCCD = @CCCD");
                parameters.Add("@CCCD", cccd);
            }
            if (!string.IsNullOrWhiteSpace(diaChi))
            {
                updates.Add("DiaChi = @DiaChi");
                parameters.Add("@DiaChi", diaChi);
            }

            if (updates.Count == 0)
            {
                MessageBox.Show("Không có thông tin nào để cập nhật!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            query += string.Join(", ", updates) + " WHERE MaKH = @MaKhachHang";
            parameters.Add("@MaKhachHang", maKhachHang);

            using (SqlConnection conn = new SqlConnection(@"Server=LYCORIS;Database=DoAn1;User ID=admin;Password=1234;"))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        foreach (var param in parameters)
                        {
                            cmd.Parameters.AddWithValue(param.Key, param.Value);
                        }

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Cập nhật thông tin thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            txtMaKH.Clear();
                            txtTenKhachHang.Clear();
                            txtSoDienThoai.Clear();
                            txtCCCD.Clear();
                            txtDiaChi.Clear();
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy khách hàng với mã này để cập nhật!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Đã xảy ra lỗi khi cập nhật thông tin: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
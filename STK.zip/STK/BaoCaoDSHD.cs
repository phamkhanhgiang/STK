﻿using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Xceed.Words.NET;

namespace STK
{
    public partial class BaoCaoDSHD : Form
    {
        public BaoCaoDSHD()
        {
            InitializeComponent();
        }

        private void BaoCaoDSHD_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(@"Server=LYCORIS;Database=DoAn1;User ID=admin;Password=1234;"))
                {
                    conn.Open();

                    string query = @"
                SELECT 
                    SUM(CASE WHEN SoTien > 0 THEN SoTien ELSE 0 END) AS TongThu,
                    SUM(CASE WHEN SoTien < 0 THEN SoTien ELSE 0 END) AS TongChi
                FROM BienDongSoDu
                WHERE NgayGiaoDich BETWEEN @FromDate AND @ToDate;";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@FromDate", dtpFromDate.Value.Date);
                    cmd.Parameters.AddWithValue("@ToDate", dtpToDate.Value.Date);

                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        decimal tongThu = reader.IsDBNull(0) ? 0 : reader.GetDecimal(0);
                        decimal tongChi = reader.IsDBNull(1) ? 0 : reader.GetDecimal(1);
                        decimal chenhLechThu = tongThu - Math.Abs(tongChi);
                        var tongthu = String.Format("{0:0,0}", tongThu);
                        var tongchi = String.Format("{0:0,0}", Math.Abs(tongChi));
                        var chenhlechthu = String.Format("{0:0,0}", chenhLechThu);
                        lblTongThu.Text = $"{tongthu: VNĐ}";
                        lblTongChi.Text = $"{tongchi: VNĐ}";
                        lblChenhLechThu.Text = $"{chenhlechthu: VNĐ}";
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void SaveReport()
        {

        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog
                {
                    Filter = "Word Files|*.docx",
                    Title = "Lưu báo cáo doanh số hoạt động"
                };

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName;

                    using (var doc = DocX.Create(filePath))
                    {
                        var title = doc.InsertParagraph("Báo cáo doanh số hoạt động")
                                        .FontSize(16)
                                        .Bold();
                        title.Alignment = Xceed.Document.NET.Alignment.center;

                        doc.InsertParagraph("\n");

                        string tongTienNap = lblTongThu.Text;
                        string tongTienRut = lblTongChi.Text;
                        string chenhlechThu = lblChenhLechThu.Text;

                        doc.InsertParagraph($"Tổng số tiền nạp vào: {tongTienNap}").FontSize(12);
                        doc.InsertParagraph($"Tổng số tiền rút ra: {tongTienRut}").FontSize(12);
                        var chenhlech = 
                        doc.InsertParagraph($"Chênh lệch tổng thu/chi: {chenhlechThu}").FontSize(12);
                        doc.Save();
                    }

                    MessageBox.Show("Báo cáo đã được lưu thành công!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void lblChenhLechThu_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿namespace STK
{
    partial class HomeScreen
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            pictureBox1 = new PictureBox();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            button6 = new Button();
            label6 = new Label();
            pictureBox3 = new PictureBox();
            panel4 = new Panel();
            label2 = new Label();
            label1 = new Label();
            panel5 = new Panel();
            lblSoSoTietKiem = new Label();
            lblSoKhachHang = new Label();
            label8 = new Label();
            label7 = new Label();
            pictureBox2 = new PictureBox();
            button9 = new Button();
            label11 = new Label();
            button4 = new Button();
            panel_main = new Panel();
            guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            guna2GradientButton4 = new Guna.UI2.WinForms.Guna2GradientButton();
            guna2GradientButton3 = new Guna.UI2.WinForms.Guna2GradientButton();
            guna2GradientButton2 = new Guna.UI2.WinForms.Guna2GradientButton();
            guna2GradientButton1 = new Guna.UI2.WinForms.Guna2GradientButton();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel_main.SuspendLayout();
            guna2CustomGradientPanel1.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Location = new Point(250, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(942, 637);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(0, 0);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(0, 0);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 0;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(0, 0);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 0;
            // 
            // label3
            // 
            label3.Location = new Point(0, 0);
            label3.Name = "label3";
            label3.Size = new Size(100, 23);
            label3.TabIndex = 0;
            // 
            // label4
            // 
            label4.Location = new Point(0, 0);
            label4.Name = "label4";
            label4.Size = new Size(100, 23);
            label4.TabIndex = 0;
            // 
            // label5
            // 
            label5.Location = new Point(0, 0);
            label5.Name = "label5";
            label5.Size = new Size(100, 23);
            label5.TabIndex = 0;
            // 
            // button6
            // 
            button6.Location = new Point(0, 0);
            button6.Name = "button6";
            button6.Size = new Size(75, 23);
            button6.TabIndex = 0;
            // 
            // label6
            // 
            label6.Location = new Point(0, 0);
            label6.Name = "label6";
            label6.Size = new Size(100, 23);
            label6.TabIndex = 0;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Resource1.panorama_3327550_1920;
            pictureBox3.Location = new Point(0, 171);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(832, 333);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 0;
            pictureBox3.TabStop = false;
            // 
            // panel4
            // 
            panel4.BackColor = Color.FromArgb(2, 35, 38);
            panel4.Controls.Add(label2);
            panel4.Controls.Add(label1);
            panel4.Location = new Point(0, 72);
            panel4.Name = "panel4";
            panel4.Size = new Size(826, 93);
            panel4.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label2.ForeColor = Color.FromArgb(54, 132, 107);
            label2.Location = new Point(57, 43);
            label2.Name = "label2";
            label2.Size = new Size(79, 30);
            label2.TabIndex = 1;
            label2.Text = "Admin";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F);
            label1.ForeColor = Color.White;
            label1.Location = new Point(57, 22);
            label1.Name = "label1";
            label1.Size = new Size(72, 21);
            label1.TabIndex = 0;
            label1.Text = "Xin chào,";
            // 
            // panel5
            // 
            panel5.BackColor = Color.FromArgb(2, 35, 38);
            panel5.Controls.Add(lblSoSoTietKiem);
            panel5.Controls.Add(lblSoKhachHang);
            panel5.Controls.Add(label8);
            panel5.Controls.Add(label7);
            panel5.Location = new Point(0, 510);
            panel5.Name = "panel5";
            panel5.Size = new Size(826, 144);
            panel5.TabIndex = 2;
            // 
            // lblSoSoTietKiem
            // 
            lblSoSoTietKiem.AutoSize = true;
            lblSoSoTietKiem.Font = new Font("Segoe UI", 12F);
            lblSoSoTietKiem.ForeColor = Color.White;
            lblSoSoTietKiem.Location = new Point(217, 66);
            lblSoSoTietKiem.Name = "lblSoSoTietKiem";
            lblSoSoTietKiem.Size = new Size(19, 21);
            lblSoSoTietKiem.TabIndex = 4;
            lblSoSoTietKiem.Text = "...";
            // 
            // lblSoKhachHang
            // 
            lblSoKhachHang.AutoSize = true;
            lblSoKhachHang.Font = new Font("Segoe UI", 12F);
            lblSoKhachHang.ForeColor = Color.White;
            lblSoKhachHang.Location = new Point(193, 34);
            lblSoKhachHang.Name = "lblSoKhachHang";
            lblSoKhachHang.Size = new Size(19, 21);
            lblSoKhachHang.TabIndex = 3;
            lblSoKhachHang.Text = "...";
            lblSoKhachHang.Click += label9_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F);
            label8.ForeColor = Color.White;
            label8.Location = new Point(80, 66);
            label8.Name = "label8";
            label8.Size = new Size(141, 21);
            label8.TabIndex = 2;
            label8.Text = "Tổng số sổ đã mở: ";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F);
            label7.ForeColor = Color.White;
            label7.Location = new Point(80, 34);
            label7.Name = "label7";
            label7.Size = new Size(119, 21);
            label7.TabIndex = 1;
            label7.Text = "Số khách hàng: ";
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = Color.FromArgb(2, 35, 38);
            pictureBox2.Image = Resource1.bank;
            pictureBox2.Location = new Point(53, 38);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(114, 107);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            // 
            // button9
            // 
            button9.BackColor = Color.FromArgb(2, 35, 38);
            button9.FlatAppearance.BorderSize = 0;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 163);
            button9.ForeColor = Color.FromArgb(154, 192, 181);
            button9.Location = new Point(53, 151);
            button9.Name = "button9";
            button9.Size = new Size(119, 46);
            button9.TabIndex = 5;
            button9.Text = "Trang chủ";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
            label11.ForeColor = Color.FromArgb(2, 35, 38);
            label11.Location = new Point(35, 25);
            label11.Name = "label11";
            label11.Size = new Size(225, 25);
            label11.TabIndex = 3;
            label11.Text = "Ngân hàng nhóm 21, UIT";
            // 
            // button4
            // 
            button4.BackColor = Color.White;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 163);
            button4.ForeColor = Color.FromArgb(2, 35, 38);
            button4.Location = new Point(723, -3);
            button4.Name = "button4";
            button4.Size = new Size(109, 75);
            button4.TabIndex = 4;
            button4.Text = "Thoát";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click_1;
            // 
            // panel_main
            // 
            panel_main.BackColor = Color.White;
            panel_main.Controls.Add(button4);
            panel_main.Controls.Add(label11);
            panel_main.Controls.Add(panel5);
            panel_main.Controls.Add(panel4);
            panel_main.Controls.Add(pictureBox3);
            panel_main.Location = new Point(230, 0);
            panel_main.Name = "panel_main";
            panel_main.Size = new Size(826, 641);
            panel_main.TabIndex = 3;
            // 
            // guna2CustomGradientPanel1
            // 
            guna2CustomGradientPanel1.Controls.Add(button9);
            guna2CustomGradientPanel1.Controls.Add(guna2GradientButton4);
            guna2CustomGradientPanel1.Controls.Add(guna2GradientButton3);
            guna2CustomGradientPanel1.Controls.Add(guna2GradientButton2);
            guna2CustomGradientPanel1.Controls.Add(guna2GradientButton1);
            guna2CustomGradientPanel1.Controls.Add(pictureBox2);
            guna2CustomGradientPanel1.CustomizableEdges = customizableEdges9;
            guna2CustomGradientPanel1.Dock = DockStyle.Left;
            guna2CustomGradientPanel1.FillColor = Color.FromArgb(0, 40, 0);
            guna2CustomGradientPanel1.FillColor2 = Color.FromArgb(2, 35, 38);
            guna2CustomGradientPanel1.FillColor3 = Color.FromArgb(2, 35, 38);
            guna2CustomGradientPanel1.FillColor4 = Color.FromArgb(2, 35, 38);
            guna2CustomGradientPanel1.Location = new Point(0, 0);
            guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            guna2CustomGradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges10;
            guna2CustomGradientPanel1.Size = new Size(230, 641);
            guna2CustomGradientPanel1.TabIndex = 4;
            // 
            // guna2GradientButton4
            // 
            guna2GradientButton4.CustomizableEdges = customizableEdges1;
            guna2GradientButton4.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientButton4.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientButton4.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientButton4.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientButton4.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientButton4.FillColor = Color.FromArgb(0, 40, 0);
            guna2GradientButton4.FillColor2 = Color.FromArgb(2, 35, 38);
            guna2GradientButton4.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            guna2GradientButton4.ForeColor = Color.White;
            guna2GradientButton4.Location = new Point(0, 577);
            guna2GradientButton4.Name = "guna2GradientButton4";
            guna2GradientButton4.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2GradientButton4.Size = new Size(231, 64);
            guna2GradientButton4.TabIndex = 6;
            guna2GradientButton4.Text = "Tài khoản";
            guna2GradientButton4.Click += button5_Click;
            // 
            // guna2GradientButton3
            // 
            guna2GradientButton3.CustomizableEdges = customizableEdges3;
            guna2GradientButton3.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientButton3.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientButton3.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientButton3.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientButton3.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientButton3.FillColor = Color.FromArgb(0, 40, 0);
            guna2GradientButton3.FillColor2 = Color.FromArgb(2, 35, 38);
            guna2GradientButton3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            guna2GradientButton3.ForeColor = Color.White;
            guna2GradientButton3.Location = new Point(0, 306);
            guna2GradientButton3.Name = "guna2GradientButton3";
            guna2GradientButton3.ShadowDecoration.CustomizableEdges = customizableEdges4;
            guna2GradientButton3.Size = new Size(231, 64);
            guna2GradientButton3.TabIndex = 5;
            guna2GradientButton3.Text = "Báo cáo Sổ tiết kiệm";
            guna2GradientButton3.Click += button2_Click;
            // 
            // guna2GradientButton2
            // 
            guna2GradientButton2.CustomizableEdges = customizableEdges5;
            guna2GradientButton2.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientButton2.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientButton2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientButton2.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientButton2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientButton2.FillColor = Color.FromArgb(0, 40, 0);
            guna2GradientButton2.FillColor2 = Color.FromArgb(2, 35, 38);
            guna2GradientButton2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            guna2GradientButton2.ForeColor = Color.White;
            guna2GradientButton2.Location = new Point(0, 376);
            guna2GradientButton2.Name = "guna2GradientButton2";
            guna2GradientButton2.ShadowDecoration.CustomizableEdges = customizableEdges6;
            guna2GradientButton2.Size = new Size(231, 64);
            guna2GradientButton2.TabIndex = 4;
            guna2GradientButton2.Text = "Báo cáo doanh số hoạt động";
            guna2GradientButton2.Click += button3_Click;
            // 
            // guna2GradientButton1
            // 
            guna2GradientButton1.CustomizableEdges = customizableEdges7;
            guna2GradientButton1.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientButton1.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientButton1.FillColor = Color.FromArgb(0, 40, 0);
            guna2GradientButton1.FillColor2 = Color.FromArgb(2, 35, 38);
            guna2GradientButton1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            guna2GradientButton1.ForeColor = Color.White;
            guna2GradientButton1.Location = new Point(0, 236);
            guna2GradientButton1.Name = "guna2GradientButton1";
            guna2GradientButton1.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2GradientButton1.Size = new Size(231, 64);
            guna2GradientButton1.TabIndex = 0;
            guna2GradientButton1.Text = "Quản lý khách hàng";
            guna2GradientButton1.Click += button1_Click;
            // 
            // HomeScreen
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1054, 641);
            Controls.Add(guna2CustomGradientPanel1);
            Controls.Add(panel_main);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "HomeScreen";
            Text = "Quản lý sổ tiết kiệm";
            Load += Form1_Load_1;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel_main.ResumeLayout(false);
            panel_main.PerformLayout();
            guna2CustomGradientPanel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label6;

        #endregion

        private PictureBox pictureBox3;
        private Panel panel4;
        private Label label2;
        private Label label1;
        private Panel panel5;
        private Label lblSoSoTietKiem;
        private Button button9;
        private Label lblSoKhachHang;
        private PictureBox pictureBox2;
        private Label label8;
        private Label label7;
        private Label label11;
        private Button button4;
        private Panel panel_main;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton1;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton4;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton3;
        private Guna.UI2.WinForms.Guna2GradientButton guna2GradientButton2;
    }
}

﻿using System.Data.SqlClient;
using System;
namespace STK
{
    public partial class HomeScreen : Form
    {
        public HomeScreen()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openChildForm(new QuanlyKhachHang());
        }
        private void button2_Click(object sender, EventArgs e)
        {
            openChildForm(new BaoCaoSTK());
        }
        private void button5_Click(object sender, EventArgs e)
        {
            openChildForm(new Admin());
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            openChildForm(new BaoCaoDSHD());
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(@"Server=LYCORIS;Database=DoAn1;User ID=admin;Password=1234;"))
                {
                    conn.Open();

                    string query = @"
                SELECT 
                    (SELECT COUNT(*) FROM KhachHang) AS SoKhachHang,
                    (SELECT COUNT(*) FROM SoTietKiem) AS TongSoSoDaMo;";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        int soKhachHang = reader.GetInt32(0);
                        int tongSoSoDaMo = reader.GetInt32(1);

                        lblSoKhachHang.Text = $"{soKhachHang}";
                        lblSoSoTietKiem.Text = $"{tongSoSoDaMo}";
                    }

                    reader.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private Form activeForm = null;

        public void openChildForm(Form childForm)
        {
            if (activeForm != null)
                activeForm.Close();

            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panel_main.Controls.Add(childForm);
            panel_main.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void panel_main_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            HomeScreen home = new HomeScreen();
            home.Show();
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

﻿namespace STK
{
    partial class DongSo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            txtMaSo = new TextBox();
            button10 = new Button();
            button1 = new Button();
            label1 = new Label();
            txtHoTen = new TextBox();
            label3 = new Label();
            txtSoTien = new TextBox();
            dtpNgayDong = new DateTimePicker();
            label4 = new Label();
            label5 = new Label();
            panel2 = new Panel();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label2.Location = new Point(35, 155);
            label2.Name = "label2";
            label2.Size = new Size(93, 15);
            label2.TabIndex = 14;
            label2.Text = "Mã sổ tiết kiệm";
            // 
            // txtMaSo
            // 
            txtMaSo.Location = new Point(183, 147);
            txtMaSo.Name = "txtMaSo";
            txtMaSo.Size = new Size(182, 23);
            txtMaSo.TabIndex = 29;
            txtMaSo.TextChanged += txtMaKH_TextChanged;
            // 
            // button10
            // 
            button10.BackColor = Color.DarkGreen;
            button10.FlatAppearance.BorderSize = 0;
            button10.FlatStyle = FlatStyle.Flat;
            button10.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button10.ForeColor = Color.White;
            button10.Location = new Point(223, 384);
            button10.Name = "button10";
            button10.Size = new Size(130, 32);
            button10.TabIndex = 30;
            button10.Text = "Rút";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.DarkGreen;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(30, 384);
            button1.Name = "button1";
            button1.Size = new Size(130, 32);
            button1.TabIndex = 31;
            button1.Text = "Đóng";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label1.Location = new Point(35, 214);
            label1.Name = "label1";
            label1.Size = new Size(45, 15);
            label1.TabIndex = 32;
            label1.Text = "Họ tên";
            // 
            // txtHoTen
            // 
            txtHoTen.BackColor = Color.White;
            txtHoTen.Location = new Point(183, 206);
            txtHoTen.Name = "txtHoTen";
            txtHoTen.ReadOnly = true;
            txtHoTen.Size = new Size(182, 23);
            txtHoTen.TabIndex = 33;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label3.Location = new Point(35, 268);
            label3.Name = "label3";
            label3.Size = new Size(142, 15);
            label3.TabIndex = 34;
            label3.Text = "Số tiền hiện tại trong sổ ";
            // 
            // txtSoTien
            // 
            txtSoTien.BackColor = Color.White;
            txtSoTien.Location = new Point(183, 260);
            txtSoTien.Name = "txtSoTien";
            txtSoTien.ReadOnly = true;
            txtSoTien.Size = new Size(182, 23);
            txtSoTien.TabIndex = 35;
            txtSoTien.TextChanged += txtSoTien_TextChanged;
            // 
            // dtpNgayDong
            // 
            dtpNgayDong.Enabled = false;
            dtpNgayDong.Location = new Point(183, 328);
            dtpNgayDong.Name = "dtpNgayDong";
            dtpNgayDong.Size = new Size(182, 23);
            dtpNgayDong.TabIndex = 36;
            dtpNgayDong.Value = new DateTime(2024, 12, 31, 6, 42, 39, 0);
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label4.Location = new Point(35, 328);
            label4.Name = "label4";
            label4.Size = new Size(82, 15);
            label4.TabIndex = 37;
            label4.Text = "Ngày đóng sổ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label5.ForeColor = Color.FromArgb(2, 35, 38);
            label5.Location = new Point(50, 83);
            label5.Name = "label5";
            label5.Size = new Size(303, 46);
            label5.TabIndex = 38;
            label5.Text = "Đóng sổ tiết kiệm";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(2, 35, 38);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(397, 80);
            panel2.TabIndex = 51;
            // 
            // DongSo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(397, 451);
            Controls.Add(panel2);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(dtpNgayDong);
            Controls.Add(txtSoTien);
            Controls.Add(label3);
            Controls.Add(txtHoTen);
            Controls.Add(label1);
            Controls.Add(button1);
            Controls.Add(button10);
            Controls.Add(txtMaSo);
            Controls.Add(label2);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "DongSo";
            Text = "Đóng sổ tiết kiệm";
            Load += DongSo_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private TextBox txtMaSo;
        private Button button10;
        private Button button1;
        private Label label1;
        private TextBox txtHoTen;
        private Label label3;
        private TextBox txtSoTien;
        private DateTimePicker dtpNgayDong;
        private Label label4;
        private Label label5;
        private Panel panel2;
    }
}
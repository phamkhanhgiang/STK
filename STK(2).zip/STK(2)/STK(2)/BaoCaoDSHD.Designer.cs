﻿namespace STK
{
    partial class BaoCaoDSHD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BaoCaoDSHD));
            dtpFromDate = new DateTimePicker();
            dtpToDate = new DateTimePicker();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            lblTongThu = new Label();
            label6 = new Label();
            lblTongChi = new Label();
            label8 = new Label();
            lblChenhLechThu = new Label();
            button1 = new Button();
            panel1 = new Panel();
            button2 = new Button();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            printPreviewDialog1 = new PrintPreviewDialog();
            SuspendLayout();
            // 
            // dtpFromDate
            // 
            dtpFromDate.Location = new Point(129, 195);
            dtpFromDate.Name = "dtpFromDate";
            dtpFromDate.Size = new Size(200, 23);
            dtpFromDate.TabIndex = 0;
            // 
            // dtpToDate
            // 
            dtpToDate.Location = new Point(429, 193);
            dtpToDate.Name = "dtpToDate";
            dtpToDate.Size = new Size(200, 23);
            dtpToDate.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 30F, FontStyle.Bold);
            label1.ForeColor = Color.FromArgb(2, 35, 38);
            label1.Location = new Point(127, 112);
            label1.Name = "label1";
            label1.Size = new Size(560, 54);
            label1.TabIndex = 2;
            label1.Text = "Báo cáo doanh số hoạt động";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(71, 201);
            label2.Name = "label2";
            label2.Size = new Size(52, 15);
            label2.TabIndex = 3;
            label2.Text = "Từ ngày:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(364, 201);
            label3.Name = "label3";
            label3.Size = new Size(59, 15);
            label3.TabIndex = 4;
            label3.Text = "đến ngày:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 1, true);
            label4.Location = new Point(28, 302);
            label4.Name = "label4";
            label4.Size = new Size(371, 28);
            label4.TabIndex = 5;
            label4.Text = "Tổng số tiền nạp vào các sổ tiết kiệm:";
            // 
            // lblTongThu
            // 
            lblTongThu.AutoSize = true;
            lblTongThu.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 1, true);
            lblTongThu.Location = new Point(396, 302);
            lblTongThu.Name = "lblTongThu";
            lblTongThu.Size = new Size(27, 28);
            lblTongThu.TabIndex = 6;
            lblTongThu.Text = "...";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 1, true);
            label6.Location = new Point(28, 361);
            label6.Name = "label6";
            label6.Size = new Size(371, 28);
            label6.TabIndex = 7;
            label6.Text = "Tổng số tiền rút khỏi các sổ tiết kiệm:";
            // 
            // lblTongChi
            // 
            lblTongChi.AutoSize = true;
            lblTongChi.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 1, true);
            lblTongChi.Location = new Point(405, 361);
            lblTongChi.Name = "lblTongChi";
            lblTongChi.Size = new Size(27, 28);
            lblTongChi.TabIndex = 8;
            lblTongChi.Text = "...";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 1, true);
            label8.Location = new Point(28, 418);
            label8.Name = "label8";
            label8.Size = new Size(246, 28);
            label8.TabIndex = 9;
            label8.Text = "Chênh lệch tổng thu/chi:";
            // 
            // lblChenhLechThu
            // 
            lblChenhLechThu.AutoSize = true;
            lblChenhLechThu.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 1, true);
            lblChenhLechThu.Location = new Point(280, 418);
            lblChenhLechThu.Name = "lblChenhLechThu";
            lblChenhLechThu.Size = new Size(27, 28);
            lblChenhLechThu.TabIndex = 11;
            lblChenhLechThu.Text = "...";
            lblChenhLechThu.Click += lblChenhLechThu_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.DarkGreen;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(28, 516);
            button1.Name = "button1";
            button1.Size = new Size(232, 56);
            button1.TabIndex = 13;
            button1.Text = "Lập báo cáo";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(2, 35, 38);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(853, 100);
            panel1.TabIndex = 29;
            // 
            // button2
            // 
            button2.BackColor = Color.DarkGreen;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button2.ForeColor = Color.White;
            button2.Location = new Point(663, 190);
            button2.Name = "button2";
            button2.Size = new Size(120, 30);
            button2.TabIndex = 30;
            button2.Text = "Tìm kiếm";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // printPreviewDialog1
            // 
            printPreviewDialog1.AutoScrollMargin = new Size(0, 0);
            printPreviewDialog1.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialog1.ClientSize = new Size(400, 300);
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.Enabled = true;
            printPreviewDialog1.Icon = (Icon)resources.GetObject("printPreviewDialog1.Icon");
            printPreviewDialog1.Name = "printPreviewDialog1";
            printPreviewDialog1.Visible = false;
            // 
            // BaoCaoDSHD
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(853, 584);
            Controls.Add(button2);
            Controls.Add(panel1);
            Controls.Add(button1);
            Controls.Add(lblChenhLechThu);
            Controls.Add(label8);
            Controls.Add(lblTongChi);
            Controls.Add(label6);
            Controls.Add(lblTongThu);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dtpToDate);
            Controls.Add(dtpFromDate);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "BaoCaoDSHD";
            Text = "Báo cáo doanh số hoạt động";
            Load += BaoCaoDSHD_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DateTimePicker dtpFromDate;
        private DateTimePicker dtpToDate;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label lblTongThu;
        private Label label6;
        private Label lblTongChi;
        private Label label8;
        private Label lblChenhLechThu;
        private Button button1;
        private Panel panel1;
        private Button button2;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private PrintPreviewDialog printPreviewDialog1;
    }
}
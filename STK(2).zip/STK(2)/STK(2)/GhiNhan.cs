﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STK
{
    public partial class GhiNhan : Form
    {
        public GhiNhan()
        {
            InitializeComponent();
        }

        private void GhiNhan_Load(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMaSo.Text) || string.IsNullOrEmpty(txtSoTien.Text) || cbLoaiGiaoDich.SelectedItem == null)
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int maSo = int.Parse(txtMaSo.Text);
            decimal soTienGiaoDich = decimal.Parse(txtSoTien.Text); 
            string loaiGiaoDich = cbLoaiGiaoDich.SelectedItem.ToString(); 
            DateTime ngayGiaoDich = DateTime.Now;

            using (SqlConnection connection = new SqlConnection(@"Server=LYCORIS;Database=DoAn1;User ID=admin;Password=1234;"))
            {
                try
                {
                    connection.Open();
                    string checkQuery = "SELECT SoDu FROM SoTietKiem WHERE MaSo = @MaSo";
                    decimal soDuHienTai;
                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, connection))
                    {
                        checkCmd.Parameters.AddWithValue("@MaSo", maSo);
                        var result = checkCmd.ExecuteScalar();

                        if (result == null)
                        {
                            MessageBox.Show("Mã sổ tiết kiệm không tồn tại! Vui lòng nhập lại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            txtMaSo.Focus();
                            return;
                        }

                        soDuHienTai = (decimal)result;
                    }

                    if (loaiGiaoDich == "Rút tiền")
                    {
                        if (soTienGiaoDich > soDuHienTai)
                        {
                            MessageBox.Show("Số tiền trong sổ không đủ để rút!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        string updateQuery = "UPDATE SoTietKiem SET SoDu = SoDu - @SoTien WHERE MaSo = @MaSo";
                        using (SqlCommand updateCmd = new SqlCommand(updateQuery, connection))
                        {
                            updateCmd.Parameters.AddWithValue("@SoTien", soTienGiaoDich);
                            updateCmd.Parameters.AddWithValue("@MaSo", maSo);
                            updateCmd.ExecuteNonQuery();
                        }
                    }
                    else if (loaiGiaoDich == "Nạp tiền")
                    {

                        string updateQuery = "UPDATE SoTietKiem SET SoDu = SoDu + @SoTien WHERE MaSo = @MaSo";
                        using (SqlCommand updateCmd = new SqlCommand(updateQuery, connection))
                        {
                            updateCmd.Parameters.AddWithValue("@SoTien", soTienGiaoDich);
                            updateCmd.Parameters.AddWithValue("@MaSo", maSo);
                            updateCmd.ExecuteNonQuery();
                        }
                    }

                    string insertTransactionQuery = "INSERT INTO BienDongSoDu (MaSo, NgayGiaoDich, SoTien, SoDuCuoi, MoTa) " +
                                                    "VALUES (@MaSo, @NgayGiaoDich, @SoTien, @SoDuCuoi, @MoTa)";
                    using (SqlCommand insertCmd = new SqlCommand(insertTransactionQuery, connection))
                    {
                        insertCmd.Parameters.AddWithValue("@MaSo", maSo);
                        insertCmd.Parameters.AddWithValue("@NgayGiaoDich", ngayGiaoDich);
                        insertCmd.Parameters.AddWithValue("@SoTien", loaiGiaoDich == "Rút tiền" ? -soTienGiaoDich : soTienGiaoDich); 
                        insertCmd.Parameters.AddWithValue("@SoDuCuoi", loaiGiaoDich == "Rút tiền" ? soDuHienTai - soTienGiaoDich : soDuHienTai + soTienGiaoDich);
                        insertCmd.Parameters.AddWithValue("@MoTa", loaiGiaoDich);
                        insertCmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Giao dịch đã được ghi nhận thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    txtMaSo.Clear();
                    txtSoTien.Clear();
                    cbLoaiGiaoDich.SelectedIndex = -1;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Đã xảy ra lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                try
                {
                    string updateDoanhSoQuery = @"
        MERGE BaoCaoDoanhSoHoatDong AS target
        USING (
            SELECT 
                @NgayThongKe AS NgayThongKe,
                @MaSo AS MaSo,
                @TongThu AS TongThu,
                @TongChi AS TongChi
        ) AS source
        ON target.NgayThongKe = source.NgayThongKe AND target.MaSo = source.MaSo
        WHEN MATCHED THEN
            UPDATE SET 
                TongThu = target.TongThu + source.TongThu,
                TongChi = target.TongChi + source.TongChi
        WHEN NOT MATCHED THEN
            INSERT (NgayThongKe, MaSo, TongThu, TongChi)
            VALUES (source.NgayThongKe, source.MaSo, source.TongThu, source.TongChi);";

                    using (SqlCommand updateDoanhSoCmd = new SqlCommand(updateDoanhSoQuery, connection))
                    {
                        updateDoanhSoCmd.Parameters.AddWithValue("@NgayThongKe", ngayGiaoDich.Date);
                        updateDoanhSoCmd.Parameters.AddWithValue("@MaSo", maSo);
                        updateDoanhSoCmd.Parameters.AddWithValue("@TongThu", loaiGiaoDich == "Nạp tiền" ? soTienGiaoDich : 0);
                        updateDoanhSoCmd.Parameters.AddWithValue("@TongChi", loaiGiaoDich == "Rút tiền" ? soTienGiaoDich : 0);
                        updateDoanhSoCmd.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi khi cập nhật tổng thu, tổng chi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            this.Close();
        }

        private void cbLoaiSo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿namespace STK
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            button1 = new Button();
            label3 = new Label();
            pictureBox1 = new PictureBox();
            txtPassword = new MaskedTextBox();
            txtUsername = new TextBox();
            label1 = new Label();
            label2 = new Label();
            button9 = new Button();
            guna2GradientCircleButton1 = new Guna.UI2.WinForms.Guna2GradientCircleButton();
            guna2GradientCircleButton2 = new Guna.UI2.WinForms.Guna2GradientCircleButton();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(2, 35, 38);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(label3);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(503, 69);
            panel1.TabIndex = 0;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(2, 35, 38);
            button1.Dock = DockStyle.Right;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(374, 0);
            button1.Name = "button1";
            button1.Size = new Size(129, 69);
            button1.TabIndex = 7;
            button1.Text = "Thoát";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            label3.ForeColor = Color.White;
            label3.Location = new Point(13, 26);
            label3.Name = "label3";
            label3.Size = new Size(174, 19);
            label3.TabIndex = 7;
            label3.Text = "Ngân hàng nhóm 21, UIT";
            label3.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Resource1.bank;
            pictureBox1.Location = new Point(201, 105);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(97, 88);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // txtPassword
            // 
            txtPassword.Location = new Point(162, 297);
            txtPassword.Name = "txtPassword";
            txtPassword.Size = new Size(172, 23);
            txtPassword.TabIndex = 2;
            // 
            // txtUsername
            // 
            txtUsername.Location = new Point(162, 240);
            txtUsername.Name = "txtUsername";
            txtUsername.Size = new Size(172, 23);
            txtUsername.TabIndex = 3;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10F);
            label1.ForeColor = Color.FromArgb(25, 51, 17);
            label1.Location = new Point(157, 218);
            label1.Name = "label1";
            label1.Size = new Size(103, 19);
            label1.TabIndex = 4;
            label1.Text = "Tên đăng nhập:";
            label1.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10F);
            label2.ForeColor = Color.FromArgb(25, 51, 17);
            label2.Location = new Point(157, 275);
            label2.Name = "label2";
            label2.Size = new Size(71, 19);
            label2.TabIndex = 5;
            label2.Text = "Mật khẩu:";
            label2.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // button9
            // 
            button9.BackColor = Color.DarkGreen;
            button9.FlatAppearance.BorderSize = 0;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button9.ForeColor = Color.White;
            button9.Location = new Point(162, 343);
            button9.Name = "button9";
            button9.Size = new Size(172, 27);
            button9.TabIndex = 6;
            button9.Text = "Đăng nhập";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // guna2GradientCircleButton1
            // 
            guna2GradientCircleButton1.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientCircleButton1.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientCircleButton1.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientCircleButton1.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientCircleButton1.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientCircleButton1.FillColor = Color.FromArgb(2, 35, 38);
            guna2GradientCircleButton1.FillColor2 = Color.FromArgb(54, 132, 107);
            guna2GradientCircleButton1.Font = new Font("Segoe UI", 9F);
            guna2GradientCircleButton1.ForeColor = Color.White;
            guna2GradientCircleButton1.Location = new Point(-105, 285);
            guna2GradientCircleButton1.Name = "guna2GradientCircleButton1";
            guna2GradientCircleButton1.ShadowDecoration.CustomizableEdges = customizableEdges1;
            guna2GradientCircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2GradientCircleButton1.Size = new Size(261, 230);
            guna2GradientCircleButton1.TabIndex = 31;
            // 
            // guna2GradientCircleButton2
            // 
            guna2GradientCircleButton2.DisabledState.BorderColor = Color.DarkGray;
            guna2GradientCircleButton2.DisabledState.CustomBorderColor = Color.DarkGray;
            guna2GradientCircleButton2.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            guna2GradientCircleButton2.DisabledState.FillColor2 = Color.FromArgb(169, 169, 169);
            guna2GradientCircleButton2.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            guna2GradientCircleButton2.FillColor = Color.FromArgb(54, 132, 107);
            guna2GradientCircleButton2.FillColor2 = Color.FromArgb(2, 35, 38);
            guna2GradientCircleButton2.Font = new Font("Segoe UI", 9F);
            guna2GradientCircleButton2.ForeColor = Color.White;
            guna2GradientCircleButton2.Location = new Point(400, 118);
            guna2GradientCircleButton2.Name = "guna2GradientCircleButton2";
            guna2GradientCircleButton2.ShadowDecoration.CustomizableEdges = customizableEdges2;
            guna2GradientCircleButton2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle;
            guna2GradientCircleButton2.Size = new Size(223, 202);
            guna2GradientCircleButton2.TabIndex = 32;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(503, 432);
            Controls.Add(guna2GradientCircleButton2);
            Controls.Add(guna2GradientCircleButton1);
            Controls.Add(button9);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtUsername);
            Controls.Add(txtPassword);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "Login";
            Text = "Đăng nhập";
            Load += Login_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox1;
        private MaskedTextBox txtPassword;
        private TextBox txtUsername;
        private Label label1;
        private Label label2;
        private Button button9;
        private Label label3;
        private Button button1;
        private Guna.UI2.WinForms.Guna2GradientCircleButton guna2GradientCircleButton1;
        private Guna.UI2.WinForms.Guna2GradientCircleButton guna2GradientCircleButton2;
    }
}
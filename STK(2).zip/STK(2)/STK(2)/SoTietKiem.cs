﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace STK
{
    public partial class SoTietKiem : Form
    {
        public SoTietKiem()
        {
            InitializeComponent();
        }
        private void button10_Click(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(@"Server=LYCORIS;Database=DoAn1;User ID=admin;Password=1234;"))
            {

                try
                {
                    connection.Open();

                    if (!int.TryParse(txtMaKH.Text, out int maKH))
                    {
                        MessageBox.Show("Mã khách hàng phải là số nguyên hợp lệ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (!decimal.TryParse(txtSoDu.Text, out decimal soDu) || soDu < 0)
                    {
                        MessageBox.Show("Vui lòng nhập số dư hợp lệ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    string loaiSo = cbLoaiSo.SelectedItem?.ToString();
                    if (string.IsNullOrEmpty(loaiSo))
                    {
                        MessageBox.Show("Vui lòng chọn loại sổ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    string checkCustomerQuery = "SELECT COUNT(*) FROM KhachHang WHERE MaKH = @MaKH";
                    using (SqlCommand checkCmd = new SqlCommand(checkCustomerQuery, connection))
                    {
                        checkCmd.Parameters.AddWithValue("@MaKH", maKH);
                        int customerExists = (int)checkCmd.ExecuteScalar();

                        if (customerExists == 0)
                        {
                            MessageBox.Show("Mã khách hàng không tồn tại. Vui lòng nhập lại!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }

                    string insertQuery = @"
            DECLARE @InsertedTable TABLE (MaSo INT);
            INSERT INTO SoTietKiem (MaKH, NgayMo, SoDu, LoaiSo)
            OUTPUT INSERTED.MaSo INTO @InsertedTable
            VALUES (@MaKH, @NgayMo, @SoDu, @LoaiSo);
            SELECT MaSo FROM @InsertedTable;";
                    using (SqlCommand insertCmd = new SqlCommand(insertQuery, connection))
                    {
                        DateTime ngayMo = DateTime.Now;

                        insertCmd.Parameters.AddWithValue("@MaKH", maKH);
                        insertCmd.Parameters.AddWithValue("@NgayMo", ngayMo);
                        insertCmd.Parameters.AddWithValue("@SoDu", soDu);
                        insertCmd.Parameters.AddWithValue("@LoaiSo", loaiSo);

                        object result = insertCmd.ExecuteScalar();

                        if (result != null && int.TryParse(result.ToString(), out int maSoMoi))
                        {
                            txtMaSo.Text = maSoMoi.ToString();

                            MessageBox.Show("Thêm sổ tiết kiệm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            txtMaKH.Clear();
                            txtSoDu.Clear();
                            cbLoaiSo.SelectedIndex = -1;

                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Thêm sổ tiết kiệm thất bại!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Đã xảy ra lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void SoTietKiem_Load(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(@"Server=LYCORIS;Database=DoAn1;User ID=admin;Password=1234;"))
            {
                try
                {
                    connection.Open();

                    string query = "SELECT ISNULL(MAX(MaSo), 0) + 1 AS NextMaSo FROM SoTietKiem";
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        int nextMaSo = (int)cmd.ExecuteScalar();

                        txtMaSo.Text = nextMaSo.ToString();
                        txtMaSo.Enabled = false;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Đã xảy ra lỗi khi tải mã số: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void txtMaSo_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿namespace STK
{
    partial class SoTietKiem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtSoDu = new TextBox();
            txtMaSo = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            dateTimePicker1 = new DateTimePicker();
            cbLoaiSo = new ComboBox();
            panel1 = new Panel();
            button10 = new Button();
            label6 = new Label();
            txtMaKH = new TextBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // txtSoDu
            // 
            txtSoDu.Location = new Point(154, 304);
            txtSoDu.Name = "txtSoDu";
            txtSoDu.Size = new Size(182, 23);
            txtSoDu.TabIndex = 20;
            // 
            // txtMaSo
            // 
            txtMaSo.BackColor = Color.White;
            txtMaSo.Location = new Point(154, 124);
            txtMaSo.Name = "txtMaSo";
            txtMaSo.ReadOnly = true;
            txtMaSo.Size = new Size(182, 23);
            txtMaSo.TabIndex = 18;
            txtMaSo.TextChanged += txtMaSo_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label5.Location = new Point(23, 367);
            label5.Name = "label5";
            label5.Size = new Size(44, 15);
            label5.TabIndex = 16;
            label5.Text = "Loại sổ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label4.Location = new Point(23, 243);
            label4.Name = "label4";
            label4.Size = new Size(57, 15);
            label4.TabIndex = 15;
            label4.Text = "Ngày mở";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label3.Location = new Point(23, 304);
            label3.Name = "label3";
            label3.Size = new Size(39, 15);
            label3.TabIndex = 14;
            label3.Text = "Số dư";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label2.Location = new Point(23, 127);
            label2.Name = "label2";
            label2.Size = new Size(93, 15);
            label2.TabIndex = 13;
            label2.Text = "Mã sổ tiết kiệm";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 30F, FontStyle.Bold);
            label1.ForeColor = Color.FromArgb(2, 35, 38);
            label1.Location = new Point(12, 57);
            label1.Name = "label1";
            label1.Size = new Size(361, 54);
            label1.TabIndex = 12;
            label1.Text = "Thêm sổ tiết kiệm";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Enabled = false;
            dateTimePicker1.Location = new Point(154, 243);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(182, 23);
            dateTimePicker1.TabIndex = 24;
            dateTimePicker1.Value = new DateTime(2024, 12, 31, 6, 42, 39, 0);
            // 
            // cbLoaiSo
            // 
            cbLoaiSo.FormattingEnabled = true;
            cbLoaiSo.Items.AddRange(new object[] { "1 tháng", "3 tháng", "6 tháng", "9 tháng", "12 tháng", "24 tháng" });
            cbLoaiSo.Location = new Point(154, 359);
            cbLoaiSo.Name = "cbLoaiSo";
            cbLoaiSo.Size = new Size(182, 23);
            cbLoaiSo.TabIndex = 25;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(2, 35, 38);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(379, 62);
            panel1.TabIndex = 26;
            // 
            // button10
            // 
            button10.BackColor = Color.DarkGreen;
            button10.FlatAppearance.BorderSize = 0;
            button10.FlatStyle = FlatStyle.Flat;
            button10.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button10.ForeColor = Color.White;
            button10.Location = new Point(206, 405);
            button10.Name = "button10";
            button10.Size = new Size(130, 32);
            button10.TabIndex = 14;
            button10.Text = "Thêm";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label6.Location = new Point(23, 187);
            label6.Name = "label6";
            label6.Size = new Size(90, 15);
            label6.TabIndex = 27;
            label6.Text = "Mã khách hàng";
            // 
            // txtMaKH
            // 
            txtMaKH.Location = new Point(154, 184);
            txtMaKH.Name = "txtMaKH";
            txtMaKH.Size = new Size(182, 23);
            txtMaKH.TabIndex = 28;
            // 
            // button1
            // 
            button1.BackColor = Color.DarkGreen;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(23, 405);
            button1.Name = "button1";
            button1.Size = new Size(130, 32);
            button1.TabIndex = 29;
            button1.Text = "Đóng";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // SoTietKiem
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(379, 464);
            Controls.Add(button1);
            Controls.Add(txtMaKH);
            Controls.Add(label6);
            Controls.Add(button10);
            Controls.Add(panel1);
            Controls.Add(cbLoaiSo);
            Controls.Add(dateTimePicker1);
            Controls.Add(txtSoDu);
            Controls.Add(txtMaSo);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "SoTietKiem";
            Text = "Thêm sổ tiết kiệm";
            Load += SoTietKiem_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtSoDu;
        private TextBox txtMaSo;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private DateTimePicker dateTimePicker1;
        private ComboBox cbLoaiSo;
        private Panel panel1;
        private Button button10;
        private Label label6;
        private TextBox txtMaKH;
        private Button button1;
    }
}
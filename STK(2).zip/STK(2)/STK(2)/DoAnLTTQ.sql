﻿	DROP DATABASE IF EXISTS DoAn1;

	CREATE DATABASE DoAn1;
	USE DoAn1;

	CREATE TABLE TaiKhoan (
		Username NVARCHAR(50) PRIMARY KEY,
		Password NVARCHAR(50) NOT NULL,
		Email NVARCHAR(100) NOT NULL
	);

	CREATE TABLE KhachHang (
		MaKH INT PRIMARY KEY IDENTITY(1,1),
		HoTen NVARCHAR(100) NOT NULL,
		CCCD NVARCHAR(20) UNIQUE,
		SDT NVARCHAR(15) UNIQUE,
		DiaChi NVARCHAR(255) NOT NULL
	);

		CREATE TABLE SoTietKiem (
		MaSo INT PRIMARY KEY IDENTITY(1,1),
		MaKH INT NOT NULL, 
		NgayMo DATE NOT NULL,
		SoDu DECIMAL(18, 2) NOT NULL,
		LoaiSo NVARCHAR(50) NOT NULL,
		FOREIGN KEY (MaKH) REFERENCES KhachHang(MaKH) 
	);
	ALTER TABLE SoTietKiem ADD NgayDong DATE NULL;


	CREATE TABLE BienDongSoDu (
		MaSo INT,
		NgayGiaoDich DATE NOT NULL,
		SoTien DECIMAL(18, 2) NOT NULL,
		SoDuCuoi DECIMAL(18, 2) NOT NULL,
		MoTa NVARCHAR(255) NOT NULL,
		FOREIGN KEY (MaSo) REFERENCES SoTietKiem(MaSo)
	);


	CREATE TABLE BaoCaoDoanhSoHoatDong (
    NgayThongKe DATE NOT NULL,
    MaSo INT NOT NULL,
    TongThu DECIMAL(18, 2) NOT NULL DEFAULT 0,
    TongChi DECIMAL(18, 2) NOT NULL DEFAULT 0,
    PRIMARY KEY (NgayThongKe, MaSo),
    FOREIGN KEY (MaSo) REFERENCES SoTietKiem(MaSo)
);

	CREATE TABLE BaoCaoMoDongSo (
    NgayThongKe DATE NOT NULL,
    MaSo INT NOT NULL,
    SoMo INT NOT NULL DEFAULT 0,
    SoDong INT NOT NULL DEFAULT 0,
    PRIMARY KEY (NgayThongKe, MaSo),
    FOREIGN KEY (MaSo) REFERENCES SoTietKiem(MaSo)
);

	GO

CREATE TRIGGER trg_UpdateSoMo
ON SoTietKiem
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    MERGE BaoCaoMoDongSo AS target
    USING (SELECT NgayMo AS NgayThongKe, MaSo, 1 AS SoMo, 0 AS SoDong FROM inserted) AS source
    ON target.NgayThongKe = source.NgayThongKe AND target.MaSo = source.MaSo
    WHEN MATCHED THEN
        UPDATE SET SoMo = target.SoMo + 1
    WHEN NOT MATCHED THEN
        INSERT (NgayThongKe, MaSo, SoMo, SoDong)
        VALUES (source.NgayThongKe, source.MaSo, source.SoMo, source.SoDong);
END;

GO

CREATE OR ALTER TRIGGER trg_UpdateSoDong
ON SoTietKiem
AFTER DELETE
AS
BEGIN
    SET NOCOUNT ON;

    MERGE BaoCaoMoDongSo AS target
    USING (
        SELECT 
            GETDATE() AS NgayThongKe,
            MaSo, 
            0 AS SoMo, 
            1 AS SoDong
        FROM deleted
    ) AS source
    ON target.NgayThongKe = source.NgayThongKe AND target.MaSo = source.MaSo
    WHEN MATCHED THEN
        UPDATE SET SoDong = target.SoDong + 1
    WHEN NOT MATCHED THEN
        INSERT (NgayThongKe, MaSo, SoMo, SoDong)
        VALUES (source.NgayThongKe, source.MaSo, source.SoMo, source.SoDong);
END;

GO

CREATE OR ALTER TRIGGER trg_UpdateSoDong
ON SoTietKiem
AFTER DELETE
AS
BEGIN
    SET NOCOUNT ON;

    MERGE BaoCaoMoDongSo AS target
    USING (
        SELECT 
            GETDATE() AS NgayThongKe, 
            MaSo, 
            0 AS SoMo, 
            1 AS SoDong
        FROM deleted
    ) AS source
    ON target.NgayThongKe = source.NgayThongKe AND target.MaSo = source.MaSo
    WHEN MATCHED THEN
        UPDATE SET SoDong = target.SoDong + 1
    WHEN NOT MATCHED THEN
        INSERT (NgayThongKe, MaSo, SoMo, SoDong)
        VALUES (source.NgayThongKe, source.MaSo, source.SoMo, source.SoDong);
END;

GO


CREATE TRIGGER trg_UpdateDoanhSoHoatDong
ON BienDongSoDu
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    MERGE BaoCaoDoanhSoHoatDong AS target
    USING (
        SELECT 
            NgayGiaoDich AS NgayThongKe,
            MaSo,
            SUM(CASE WHEN MoTa = 'Nạp tiền' THEN SoTien ELSE 0 END) AS TongThu,
            SUM(CASE WHEN MoTa = 'Rút tiền' THEN SoTien ELSE 0 END) AS TongChi
        FROM inserted
        GROUP BY NgayGiaoDich, MaSo
    ) AS source
    ON target.NgayThongKe = source.NgayThongKe AND target.MaSo = source.MaSo
    WHEN MATCHED THEN
        UPDATE SET 
            TongThu = target.TongThu + source.TongThu,
            TongChi = target.TongChi + source.TongChi
    WHEN NOT MATCHED THEN
        INSERT (NgayThongKe, MaSo, TongThu, TongChi)
        VALUES (source.NgayThongKe, source.MaSo, source.TongThu, source.TongChi);
END;

GO

SELECT * FROM TaiKhoan;
SELECT * FROM KhachHang;
SELECT * FROM SoTietKiem;
SELECT * FROM BienDongSoDu;
SELECT * FROM BaoCaoDoanhSoHoatDong;
SELECT * FROM BaoCaoMoDongSo;


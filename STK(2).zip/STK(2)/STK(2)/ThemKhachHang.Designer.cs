﻿namespace STK
{
    partial class ThemKhachHang
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtMaKhachHang = new TextBox();
            txtCCCD = new TextBox();
            txtTenKhachHang = new TextBox();
            txtSoDienThoai = new TextBox();
            txtDiaChi = new TextBox();
            panel1 = new Panel();
            button10 = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 30F, FontStyle.Bold);
            label1.ForeColor = Color.FromArgb(2, 35, 38);
            label1.Location = new Point(24, 75);
            label1.Name = "label1";
            label1.Size = new Size(357, 54);
            label1.TabIndex = 0;
            label1.Text = "Thêm khách hàng";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label2.Location = new Point(48, 165);
            label2.Name = "label2";
            label2.Size = new Size(90, 15);
            label2.TabIndex = 1;
            label2.Text = "Mã khách hàng";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label3.Location = new Point(48, 213);
            label3.Name = "label3";
            label3.Size = new Size(93, 15);
            label3.TabIndex = 2;
            label3.Text = "Tên khách hàng";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label4.Location = new Point(48, 256);
            label4.Name = "label4";
            label4.Size = new Size(37, 15);
            label4.TabIndex = 3;
            label4.Text = "CCCD";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label5.Location = new Point(48, 289);
            label5.Name = "label5";
            label5.Size = new Size(80, 15);
            label5.TabIndex = 4;
            label5.Text = "Số điện thoại";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label6.Location = new Point(48, 330);
            label6.Name = "label6";
            label6.Size = new Size(44, 15);
            label6.TabIndex = 5;
            label6.Text = "Địa chỉ";
            // 
            // txtMaKhachHang
            // 
            txtMaKhachHang.BackColor = Color.White;
            txtMaKhachHang.Location = new Point(179, 162);
            txtMaKhachHang.Name = "txtMaKhachHang";
            txtMaKhachHang.ReadOnly = true;
            txtMaKhachHang.Size = new Size(182, 23);
            txtMaKhachHang.TabIndex = 6;
            // 
            // txtCCCD
            // 
            txtCCCD.Location = new Point(179, 248);
            txtCCCD.Name = "txtCCCD";
            txtCCCD.Size = new Size(182, 23);
            txtCCCD.TabIndex = 7;
            // 
            // txtTenKhachHang
            // 
            txtTenKhachHang.Location = new Point(179, 213);
            txtTenKhachHang.Name = "txtTenKhachHang";
            txtTenKhachHang.Size = new Size(182, 23);
            txtTenKhachHang.TabIndex = 8;
            // 
            // txtSoDienThoai
            // 
            txtSoDienThoai.Location = new Point(179, 286);
            txtSoDienThoai.Name = "txtSoDienThoai";
            txtSoDienThoai.Size = new Size(182, 23);
            txtSoDienThoai.TabIndex = 9;
            // 
            // txtDiaChi
            // 
            txtDiaChi.Location = new Point(179, 330);
            txtDiaChi.Multiline = true;
            txtDiaChi.Name = "txtDiaChi";
            txtDiaChi.Size = new Size(182, 106);
            txtDiaChi.TabIndex = 10;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(2, 35, 38);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(393, 72);
            panel1.TabIndex = 12;
            // 
            // button10
            // 
            button10.BackColor = Color.DarkGreen;
            button10.FlatAppearance.BorderSize = 0;
            button10.FlatStyle = FlatStyle.Flat;
            button10.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button10.ForeColor = Color.White;
            button10.Location = new Point(231, 446);
            button10.Name = "button10";
            button10.Size = new Size(130, 32);
            button10.TabIndex = 13;
            button10.Text = "Thêm";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click_1;
            // 
            // button1
            // 
            button1.BackColor = Color.DarkGreen;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(24, 446);
            button1.Name = "button1";
            button1.Size = new Size(130, 32);
            button1.TabIndex = 14;
            button1.Text = "Đóng";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // ThemKhachHang
            // 
            BackColor = Color.White;
            ClientSize = new Size(393, 486);
            Controls.Add(button1);
            Controls.Add(button10);
            Controls.Add(panel1);
            Controls.Add(txtDiaChi);
            Controls.Add(txtSoDienThoai);
            Controls.Add(txtTenKhachHang);
            Controls.Add(txtCCCD);
            Controls.Add(txtMaKhachHang);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "ThemKhachHang";
            Text = "Thêm khách hàng";
            Load += ThemKhachHang_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox txtMaKhachHang;
        private TextBox txtCCCD;
        private TextBox txtTenKhachHang;
        private TextBox txtSoDienThoai;
        private TextBox txtDiaChi;
        private Panel panel1;
        private Button button10;
        private Button button1;
    }
}
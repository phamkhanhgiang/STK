﻿namespace STK
{
    partial class DSSoTietKiem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            panel1 = new Panel();
            comboBoxLoaiSo = new ComboBox();
            panel2 = new Panel();
            button9 = new Button();
            button3 = new Button();
            label4 = new Label();
            button1 = new Button();
            dataGridView1 = new DataGridView();
            label1 = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(comboBoxLoaiSo);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(dataGridView1);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(853, 584);
            panel1.TabIndex = 0;
            // 
            // comboBoxLoaiSo
            // 
            comboBoxLoaiSo.FormattingEnabled = true;
            comboBoxLoaiSo.Items.AddRange(new object[] { "Tất cả", "1 tháng", "3 tháng", "6 tháng", "9 tháng", "12 tháng", "24 tháng" });
            comboBoxLoaiSo.Location = new Point(83, 469);
            comboBoxLoaiSo.Name = "comboBoxLoaiSo";
            comboBoxLoaiSo.Size = new Size(158, 23);
            comboBoxLoaiSo.TabIndex = 51;
            comboBoxLoaiSo.SelectedIndexChanged += comboBoxLoaiSo_SelectedIndexChanged;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(2, 35, 38);
            panel2.Controls.Add(button9);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(853, 100);
            panel2.TabIndex = 50;
            // 
            // button9
            // 
            button9.BackColor = Color.FromArgb(2, 35, 38);
            button9.Dock = DockStyle.Left;
            button9.FlatAppearance.BorderSize = 0;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button9.ForeColor = Color.White;
            button9.Location = new Point(0, 0);
            button9.Name = "button9";
            button9.Size = new Size(148, 100);
            button9.TabIndex = 42;
            button9.Text = "Quay về";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button10_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.DarkGreen;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button3.ForeColor = Color.White;
            button3.Location = new Point(641, 487);
            button3.Name = "button3";
            button3.Size = new Size(167, 56);
            button3.TabIndex = 49;
            button3.Text = "Đóng sổ tiết kiệm";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label4.Location = new Point(22, 472);
            label4.Name = "label4";
            label4.Size = new Size(44, 15);
            label4.TabIndex = 48;
            label4.Text = "Loại sổ";
            // 
            // button1
            // 
            button1.BackColor = Color.DarkGreen;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(454, 487);
            button1.Name = "button1";
            button1.Size = new Size(167, 56);
            button1.TabIndex = 46;
            button1.Text = "Mở thêm sổ tiết kiệm";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button2_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(22, 187);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = SystemColors.Control;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            dataGridView1.Size = new Size(786, 247);
            dataGridView1.TabIndex = 45;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
            label1.ForeColor = Color.FromArgb(2, 35, 38);
            label1.Location = new Point(22, 116);
            label1.Name = "label1";
            label1.Size = new Size(252, 37);
            label1.TabIndex = 43;
            label1.Text = "Tất cả sổ tiết kiệm";
            // 
            // DSSoTietKiem
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(233, 250, 227);
            ClientSize = new Size(853, 584);
            Controls.Add(panel1);
            Name = "DSSoTietKiem";
            Text = "Quản lý sổ tiết kiệm";
            Load += DSSoTietKiem_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private ComboBox comboBoxLoaiSo;
        private Panel panel2;
        private Button button3;
        private Label label4;
        private Button button1;
        private DataGridView dataGridView1;
        private Label label1;
        private Button button9;
    }
}
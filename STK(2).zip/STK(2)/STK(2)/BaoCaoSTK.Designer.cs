﻿namespace STK
{
    partial class BaoCaoSTK
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            lblChenhLechMoDong = new Label();
            label8 = new Label();
            lblSoDong = new Label();
            label6 = new Label();
            lblSoMo = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            dtpDenNgay = new DateTimePicker();
            dtpTuNgay = new DateTimePicker();
            panel1 = new Panel();
            button2 = new Button();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.DarkGreen;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(36, 516);
            button1.Name = "button1";
            button1.Size = new Size(232, 56);
            button1.TabIndex = 27;
            button1.Text = "Lập báo cáo";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // lblChenhLechMoDong
            // 
            lblChenhLechMoDong.AutoSize = true;
            lblChenhLechMoDong.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 1, true);
            lblChenhLechMoDong.Location = new Point(400, 403);
            lblChenhLechMoDong.Name = "lblChenhLechMoDong";
            lblChenhLechMoDong.Size = new Size(27, 28);
            lblChenhLechMoDong.TabIndex = 25;
            lblChenhLechMoDong.Text = "...";
            lblChenhLechMoDong.Click += lblChenhlechMo_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 1, true);
            label8.Location = new Point(36, 403);
            label8.Name = "label8";
            label8.Size = new Size(368, 28);
            label8.TabIndex = 23;
            label8.Text = "Chênh lệch số lượng sổ đã mở/đóng: ";
            // 
            // lblSoDong
            // 
            lblSoDong.AutoSize = true;
            lblSoDong.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 1, true);
            lblSoDong.Location = new Point(322, 349);
            lblSoDong.Name = "lblSoDong";
            lblSoDong.Size = new Size(27, 28);
            lblSoDong.TabIndex = 22;
            lblSoDong.Text = "...";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 1, true);
            label6.Location = new Point(36, 349);
            label6.Name = "label6";
            label6.Size = new Size(280, 28);
            label6.TabIndex = 21;
            label6.Text = "Lượng sổ tiết kiệm đã đóng:";
            // 
            // lblSoMo
            // 
            lblSoMo.AutoSize = true;
            lblSoMo.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 1, true);
            lblSoMo.Location = new Point(304, 287);
            lblSoMo.Name = "lblSoMo";
            lblSoMo.Size = new Size(27, 28);
            lblSoMo.TabIndex = 20;
            lblSoMo.Text = "...";
            lblSoMo.Click += lblSoMo_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point, 1, true);
            label4.Location = new Point(36, 287);
            label4.Name = "label4";
            label4.Size = new Size(262, 28);
            label4.TabIndex = 19;
            label4.Text = "Lượng sổ tiết kiệm đã mở:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(368, 200);
            label3.Name = "label3";
            label3.Size = new Size(59, 15);
            label3.TabIndex = 18;
            label3.Text = "đến ngày:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(75, 200);
            label2.Name = "label2";
            label2.Size = new Size(52, 15);
            label2.TabIndex = 17;
            label2.Text = "Từ ngày:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 30F, FontStyle.Bold);
            label1.ForeColor = Color.FromArgb(2, 35, 38);
            label1.Location = new Point(110, 108);
            label1.Name = "label1";
            label1.Size = new Size(592, 54);
            label1.TabIndex = 16;
            label1.Text = "Báo cáo mở/đóng sổ tiết kiệm";
            // 
            // dtpDenNgay
            // 
            dtpDenNgay.Location = new Point(433, 194);
            dtpDenNgay.Name = "dtpDenNgay";
            dtpDenNgay.Size = new Size(200, 23);
            dtpDenNgay.TabIndex = 15;
            // 
            // dtpTuNgay
            // 
            dtpTuNgay.Location = new Point(133, 194);
            dtpTuNgay.Name = "dtpTuNgay";
            dtpTuNgay.Size = new Size(200, 23);
            dtpTuNgay.TabIndex = 14;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(2, 35, 38);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(853, 100);
            panel1.TabIndex = 28;
            // 
            // button2
            // 
            button2.BackColor = Color.DarkGreen;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button2.ForeColor = Color.White;
            button2.Location = new Point(663, 191);
            button2.Name = "button2";
            button2.Size = new Size(120, 30);
            button2.TabIndex = 29;
            button2.Text = "Tìm kiếm";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // BaoCaoSTK
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(853, 584);
            Controls.Add(button2);
            Controls.Add(panel1);
            Controls.Add(button1);
            Controls.Add(lblChenhLechMoDong);
            Controls.Add(label8);
            Controls.Add(lblSoDong);
            Controls.Add(label6);
            Controls.Add(lblSoMo);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dtpDenNgay);
            Controls.Add(dtpTuNgay);
            Name = "BaoCaoSTK";
            Text = "Báo cáo sổ tiết kiệm";
            Load += BaoCaoSTK_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Label lblChenhLechMoDong;
        private Label label8;
        private Label lblSoDong;
        private Label label6;
        private Label lblSoMo;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private DateTimePicker dtpDenNgay;
        private DateTimePicker dtpTuNgay;
        private Panel panel1;
        private Button button2;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace STK
{
    public partial class Login : Form
    {
        string connString = @"Server=LYCORIS;Database=DoAn1;User ID=admin;Password=1234;";
        SqlConnection conn; 


        public Login()
        {
            InitializeComponent();
            conn = new SqlConnection(connString);

        }

        private void button9_Click(object sender, EventArgs e)
        {
            bool isValid = false;

            while (!isValid) 
            {
                string username = txtUsername.Text.Trim(); 
                string password = txtPassword.Text.Trim();

                try
                {
                    conn.Open();
                    string query = "SELECT COUNT(*) FROM TaiKhoan WHERE Username = @username AND Password = @password";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);

                    int count = (int)cmd.ExecuteScalar(); 
                    if (count == 1)
                    {
                        isValid = true; 
                        MessageBox.Show("Đăng nhập thành công!");
                        HomeScreen home = new HomeScreen();
                        home.Show();
                        this.Hide(); 
                    }
                    else
                    {
                        MessageBox.Show("Sai tên đăng nhập hoặc mật khẩu. Vui lòng thử lại!", "Đăng nhập thất bại", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break; 
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi kết nối cơ sở dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    break; 
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }
    }
}

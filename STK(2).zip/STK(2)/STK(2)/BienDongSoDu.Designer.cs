﻿namespace STK
{
    partial class BienDongSoDu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            panel1 = new Panel();
            button2 = new Button();
            label4 = new Label();
            label3 = new Label();
            dtpNgayGiaoDich = new DateTimePicker();
            panel2 = new Panel();
            button1 = new Button();
            dgvGiaoDich = new DataGridView();
            button7 = new Button();
            txtMaGiaoDich = new TextBox();
            button9 = new Button();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvGiaoDich).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(button2);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(dtpNgayGiaoDich);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(dgvGiaoDich);
            panel1.Controls.Add(button7);
            panel1.Controls.Add(txtMaGiaoDich);
            panel1.Controls.Add(button9);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(853, 584);
            panel1.TabIndex = 0;
            // 
            // button2
            // 
            button2.BackColor = Color.DarkGreen;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button2.ForeColor = Color.White;
            button2.Location = new Point(60, 486);
            button2.Name = "button2";
            button2.Size = new Size(191, 56);
            button2.TabIndex = 52;
            button2.Text = "Hiển thị toàn bộ lịch sử giao dịch";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(413, 154);
            label4.Name = "label4";
            label4.Size = new Size(90, 15);
            label4.TabIndex = 51;
            label4.Text = "Ngày giao dịch:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(461, 127);
            label3.Name = "label3";
            label3.Size = new Size(42, 15);
            label3.TabIndex = 50;
            label3.Text = "Mã sổ:";
            // 
            // dtpNgayGiaoDich
            // 
            dtpNgayGiaoDich.Location = new Point(509, 150);
            dtpNgayGiaoDich.Name = "dtpNgayGiaoDich";
            dtpNgayGiaoDich.Size = new Size(187, 23);
            dtpNgayGiaoDich.TabIndex = 49;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(2, 35, 38);
            panel2.Controls.Add(button1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(853, 100);
            panel2.TabIndex = 46;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(2, 35, 38);
            button1.Dock = DockStyle.Left;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = Color.White;
            button1.Location = new Point(0, 0);
            button1.Name = "button1";
            button1.Size = new Size(119, 100);
            button1.TabIndex = 43;
            button1.Text = "Quay về";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // dgvGiaoDich
            // 
            dgvGiaoDich.AllowUserToAddRows = false;
            dgvGiaoDich.AllowUserToDeleteRows = false;
            dgvGiaoDich.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            dgvGiaoDich.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            dgvGiaoDich.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvGiaoDich.Location = new Point(60, 179);
            dgvGiaoDich.Name = "dgvGiaoDich";
            dgvGiaoDich.ReadOnly = true;
            dgvGiaoDich.Size = new Size(715, 273);
            dgvGiaoDich.TabIndex = 45;
            // 
            // button7
            // 
            button7.BackColor = Color.DarkGreen;
            button7.FlatAppearance.BorderSize = 0;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            button7.ForeColor = Color.White;
            button7.Location = new Point(700, 150);
            button7.Name = "button7";
            button7.Size = new Size(75, 23);
            button7.TabIndex = 42;
            button7.Text = "Tìm kiếm";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // txtMaGiaoDich
            // 
            txtMaGiaoDich.Location = new Point(509, 124);
            txtMaGiaoDich.Name = "txtMaGiaoDich";
            txtMaGiaoDich.Size = new Size(187, 23);
            txtMaGiaoDich.TabIndex = 41;
            // 
            // button9
            // 
            button9.BackColor = Color.DarkGreen;
            button9.FlatAppearance.BorderSize = 0;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button9.ForeColor = Color.White;
            button9.Location = new Point(584, 486);
            button9.Name = "button9";
            button9.Size = new Size(191, 56);
            button9.TabIndex = 43;
            button9.Text = "Ghi nhận";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // BienDongSoDu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(853, 584);
            Controls.Add(panel1);
            Name = "BienDongSoDu";
            Text = "Biến động số dư";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvGiaoDich).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private DateTimePicker dtpNgayGiaoDich;
        private Panel panel2;
        private Button button1;
        private DataGridView dgvGiaoDich;
        private Button button7;
        private TextBox txtMaGiaoDich;
        private Button button9;
        private Label label4;
        private Label label3;
        private Button button2;
    }
}